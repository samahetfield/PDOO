/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package napakalaki;

/**
 *
 * @author sergio
 */
public class Prize {
    private int level;
    private int treasures;
    
    public Prize(int tesoros, int nivel){
        level = nivel;
        treasures = tesoros;
    }
    
    public int getTreasures(){
        return treasures;
    }
    
    public int getLevel(){
        return level;
    }
    
    public String toString(){
        return "Treasures = " + Integer.toString(treasures) + " levels = " + Integer.toString(level);
    }
}
