/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package napakalaki;

import java.util.ArrayList;

/**
 *
 * @author sergio
 */
public class BadConsequence {
    static final int MAXTREASURES = 10;
    
    private String text ;
    private int levels ;
    private int nVisibleTreasures ;
    private int nHiddenTreasures ;
    private boolean death;
    private ArrayList<TreasureKind> specificHiddenTreasures;
    private ArrayList<TreasureKind> specificVisibleTreasures;
    
    public BadConsequence(String texto, int niveles, int nVisible, int nHidden){
        text = texto;
        levels = niveles;
        nVisibleTreasures = nVisible;
        nHiddenTreasures = nHidden;
        death = false;
        specificVisibleTreasures = new ArrayList();
        specificHiddenTreasures = new ArrayList();
    }
    
    public BadConsequence(String texto, boolean muerte){
        text = texto;
        death = muerte;
        levels = Player.MAXLEVEL;
        nVisibleTreasures = BadConsequence.MAXTREASURES;
        nHiddenTreasures = BadConsequence.MAXTREASURES;
        specificVisibleTreasures = new ArrayList();
        specificHiddenTreasures = new ArrayList();
    }
    
    public BadConsequence(String texto, int niveles, ArrayList<TreasureKind> specificV, ArrayList<TreasureKind> specificH){
        text = texto;
        levels = niveles;
        specificVisibleTreasures = specificV;
        specificHiddenTreasures = specificH;
        nVisibleTreasures = -1;
        nHiddenTreasures = -1;
        death = false;
    }
    
    public boolean isEmpty(){
        boolean vacio = false;
        
        if(nVisibleTreasures == 0 && nHiddenTreasures == 0 && specificVisibleTreasures.size() == 0){
            vacio = true;
        }
        else if(specificVisibleTreasures.size() == 0 && specificHiddenTreasures.size() == 0 && nVisibleTreasures == -1){
            vacio = true;
        }
        else if(nVisibleTreasures == BadConsequence.MAXTREASURES && levels == Player.MAXLEVEL){
            vacio = true;
        }
        
        return vacio;
    } 
    
    public int getLevel(){
        return levels;
    }
    
    public int getnVisibleTreasures(){
        return nVisibleTreasures;
    }
    
    public int getnHiddenTreasures(){
        return nHiddenTreasures;
    }
    
    public ArrayList<TreasureKind> getSpecificVisible(){
        return specificVisibleTreasures;
    }
    
    public ArrayList<TreasureKind> getSpecificHidden(){
        return specificHiddenTreasures;
    }
    
    public void substractVisibleTreasure(Treasure t){
        if(nVisibleTreasures != -1 && nVisibleTreasures > 0){
            nVisibleTreasures--;
        }
        else{
            specificVisibleTreasures.remove(t.getType());
        }
    }
    
    public void substractHiddenTreasure(Treasure t){
        if(nHiddenTreasures != -1 && nHiddenTreasures > 0){
            nHiddenTreasures--;
        }
        else{     
            specificHiddenTreasures.remove(t.getType());
                
        }
    }
    
    public BadConsequence adjustToFitTreasureLists(ArrayList<Treasure> v, ArrayList<Treasure> h){
        boolean remove = false;
        BadConsequence bc;
        ArrayList<TreasureKind> visible = new ArrayList();
        ArrayList<TreasureKind> hidden = new ArrayList();
        
        if(nVisibleTreasures != -1 && specificVisibleTreasures.size() == 0){
            for(int i=0; i<v.size(); i++){
                visible.add(v.get(i).getType());
            }

            for(int i=0; i<h.size(); i++){
                hidden.add(h.get(i).getType());
            }

            bc = new BadConsequence("", 0, this.nVisibleTreasures, this.nHiddenTreasures);

            if(v.size() > this.nVisibleTreasures){
                bc.nVisibleTreasures = 0;
            }
            else{
                bc.nVisibleTreasures = v.size();
            }

            if(h.size() > this.nHiddenTreasures){
                bc.nHiddenTreasures = 1;
            }
            else{
                bc.nHiddenTreasures = h.size();
            }
        }
        else{
          
            for(int i=0; i<v.size(); i++){
                visible.add(v.get(i).getType());
            }

            for(int i=0; i<h.size(); i++){
                hidden.add(h.get(i).getType());
            }

            bc = new BadConsequence("", 0, visible, hidden);
            for(int i=0; i<v.size(); i++){
                remove = false;
                for(int j=0; j< specificVisibleTreasures.size() && !remove; j++){
                    if(specificVisibleTreasures.get(j) == v.get(i).getType()){
                        bc.specificVisibleTreasures.remove(v.get(i));
                        bc.nVisibleTreasures--;
                        remove = true;
                    }  
                }
            }

            for(int i=0; i<h.size(); i++){
                remove = false;
                for(int j=0; j< specificHiddenTreasures.size() && !remove; j++){
                    if(specificHiddenTreasures.get(j) == h.get(i).getType()){
                        bc.specificHiddenTreasures.remove(h.get(i));
                        bc.nHiddenTreasures--;
                        remove = true;
                    }  
                }
            }
        }
        return bc;
    }
    
    public String toString(){
        return "Text = " + text + "\nLevels = " + Integer.toString(levels) 
             + "\nnVisibleTreasures = " + Integer.toString(nVisibleTreasures) 
             + "\nnHiddenTreasures = " + Integer.toString(nHiddenTreasures) 
             + "\nDeath = " + Boolean.toString(death) 
             + "\nSpecificVisibleTreasures = " + specificVisibleTreasures
             + "\nSpecificHiddenTreasures = " + specificHiddenTreasures+ "\n";
    }
}