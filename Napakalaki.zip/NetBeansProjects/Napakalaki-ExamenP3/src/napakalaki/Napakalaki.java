/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package napakalaki;

import java.util.ArrayList;

/**
 *
 * @author sergio
 */
public class Napakalaki {
    private static final Napakalaki instance = new Napakalaki();
    private Monster currentMonster;
    private CardDealer dealer;
    private ArrayList<Player> players;
    private Player currentPlayer;
    
    private Napakalaki(){
        currentMonster = new Monster("",0,null,null);
        dealer = CardDealer.getInstance();
        players = new ArrayList();
        currentPlayer = new Player(""); 
    }
    
    private void initPlayers(ArrayList<String> n){
        for(int i=0; i<n.size() ; i++){
            Player p = new Player(n.get(i));
            players.add(p);
        }
    
    }
    
    private Player nextPlayer(){
        
        boolean cambiado = false;
        if(currentPlayer.getName() == ""){
            int number;
            number = (int) (Math.random()*(players.size()));
            
            currentPlayer = players.get(number);
        }
        else{
            for(int i=0; i< players.size() && !cambiado; i++){
                if(players.get(i) == currentPlayer){
                    currentPlayer = players.get((i +1) % (players.size())); 
                    cambiado = true;
                }
            }
        }
        
        return currentPlayer;
    }
    
    private boolean nextTurnAllowed(){
        boolean puedo = false;
        
        if(currentPlayer.getName() == ""){
            puedo = true;
        }
        else{
            puedo = currentPlayer.validState();
        }
        
        return puedo;
    }
    
    private void setEnemies(){
        for(int i=0; i<players.size(); i++){
            Player p = players.get(i);
            
            int number = 0;
            while(number == i)
                number = (int) (Math.random()*players.size());
            
            p.setEnemy(players.get(number));
            
        }
    }
    
    public static Napakalaki getInstance(){
        return instance;
    }
    
    public CombatResult developCombat(){
        Monster m = currentMonster;
        CombatResult cr = currentPlayer.combat(m);
        
        dealer.giveMonsterBack(m);
        
        return cr;
    }
    
    public void discardVisibleTreasures(ArrayList<Treasure> t){
        for(int i=0; i< t.size(); i++){
            Treasure treasure = t.get(i);
            
            currentPlayer.discardVisibleTresaure(treasure);
            
            dealer.giveTreasureBack(treasure);
        }
    }
    
    public void discardHiddenTreasures(ArrayList<Treasure> t){        
        for(int i=0; i< t.size(); i++){
            Treasure treasure = t.get(i);
            
            currentPlayer.discardHiddenTreasure(treasure);
            
            dealer.giveTreasureBack(treasure);
        }
    }
    
    public void makeTreasuresVisible(ArrayList<Treasure> t){
        for(int i=0; i<t.size(); i++){
            Treasure tr = t.get(i);
            currentPlayer.makeTreasureVisible(tr);
            
        }
    }
    
    public void initGame(ArrayList<String> jugadores){
        initPlayers(jugadores);
        setEnemies();
        dealer.initCards();
        nextTurn();
    }
    
    public Player getCurrentPlayer(){
        return currentPlayer;
    }
    
    public Monster getCurrentMonster(){
        return currentMonster;
    }
    
    public boolean nextTurn(){
        boolean stateOk = this.nextTurnAllowed();
        
        if(stateOk){
            currentMonster = dealer.nextMonster();
            currentPlayer = this.nextPlayer();
            
            boolean dead = currentPlayer.isDead();
            
            if(dead){
                currentPlayer.initTreasures();
            }
        }
        
        return stateOk;
    }
    
    public boolean endOfGame(CombatResult result){
        boolean fin = false;
        
        if(result == CombatResult.WINGAME)
            fin = true;
        
        return fin;
    }
}
