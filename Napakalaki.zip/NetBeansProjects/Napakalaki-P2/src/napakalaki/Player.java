/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package napakalaki;

import java.util.ArrayList;

/**
 *
 * @author sergio
 */
public class Player {
    static final int MAXLEVEL = 10;
    private String name;
    private int level;
    private boolean dead;
    private boolean canISteal;
    private Player enemy;
    private ArrayList<Treasure> hiddenTreasures = new ArrayList();
    private ArrayList<Treasure> visibleTreasures = new ArrayList();
    private BadConsequence pendingBadConsequence;
    
    public Player(String n){
        name = n;
        level = 0;
        dead = true;
        canISteal = true;
        pendingBadConsequence = new BadConsequence("",false);
    }
    
    public String getName(){
        return name;
    }
    
    private void bringToLife(){
        dead = false;
    }
    
    private int getCombatLevel(){
        int bonus_j = level;
        for(int i=0; i<visibleTreasures.size(); i++){
            bonus_j += visibleTreasures.get(i).getBonus();
        }
        
        for(int i=0; i<hiddenTreasures.size(); i++){
            bonus_j += hiddenTreasures.get(i).getBonus();
        }
        
        return bonus_j;
    }
    
    private void incrementLevels(int l){
        level += l;
    }
    
    private void decrementLevels(int l){
        if(level-l >= 0)
            level -= l;
        else
            level = 0;
    }
    
    private void setPendingBadConsequence(BadConsequence b){
        pendingBadConsequence = b;
    }
    
    private void applyPrize(Monster m){
    
    }
    
    private void applyBadConsequence(Monster m){
    
    }
    
    private boolean canMakeTreasureVisible(Treasure t){
        return true;
    }
    
    private int howManyVisibleTreasures(TreasureKind tKind){
        int number = 0;
        
        for(int i=0; i<visibleTreasures.size(); i++){
            if(visibleTreasures.get(i).getType() == tKind)
                number++;
        }
        
        return number;
    }
    
    private void dieIfNoTreasures(){
        if(visibleTreasures.size()==0 && hiddenTreasures.size()==0){
            dead = true;
        }
    }
    
    public boolean isDead(){
        return dead;
    }
    
    public ArrayList<Treasure> getHiddenTreasures(){
        return new ArrayList();
    }
    
    public ArrayList<Treasure> getVisibleTreasures(){
        return new ArrayList();
    }
    
    public CombatResult combat(Monster m){
      return CombatResult.WIN;  
    }
    
    public void makeTreasureVisible(Treasure t){
    
    }
    
    public void discardVisibleTresaure(Treasure t){
    
    }
    
    public void discardHiddenTreasure(Treasure t){
    
    }
    
    public boolean validState(){
        boolean valid;
        if(pendingBadConsequence.isEmpty() && hiddenTreasures.size() <= 4)
            valid = true;
        else
            valid = false;
        
        return valid;
    }
    
    public void initTreasures(){
    
    }
    
    public int getLevels(){
        return level;
    }
    
    public Treasure stealTreasure(){
        return new Treasure("",0,null);
    }
    
    public void setEnemy(Player e){
        enemy= e;
    }
    
    private Treasure giveMeATreasure(){
        return new Treasure("",0,null);
    }
    
    public boolean canISteal(){
        return canISteal;
    }
    
    private boolean canYouGiveMeATreasure(){
        boolean have = false;
        
        if(visibleTreasures.size() > 0 || hiddenTreasures.size() > 0){
            have = true;
        }
        else{
            have = false;
        }
        
        return have;
    }
    
    private void haveStolen(){
        canISteal = false;
    }
    
    public void discardAllTreasures(){
    
    }
}
