/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package napakalaki;

import java.util.ArrayList;

/**
 *
 * @author sergio
 */
public class Napakalaki {
    private static final Napakalaki instance = new Napakalaki();
    private Monster currentMonster;
    private CardDealer dealer;
    private ArrayList<Player> players;
    private Player currentPlayer;
    
    private Napakalaki(){
        currentMonster = new Monster("",0,null,null);
        dealer = CardDealer.getInstance();
        players = new ArrayList();
        currentPlayer = new Player(""); 
    }
    
    private void initPlayers(ArrayList<String> n){
    
    }
    
    private Player nextPlayer(){
        return new Player("");
    }
    
    private boolean nextTurnAllowed(){
        return true;
    }
    
    private void setEnemies(){
    
    }
    
    public static Napakalaki getInstance(){
        return instance;
    }
    
    public CombatResult developCombat(){
        return CombatResult.LOSE;
    }
    
    public void discardVisibleTreasures(ArrayList<Treasure> t){
    
    }
    
    public void discardHiddenTreasures(ArrayList<Treasure> t){
    
    }
    
    public void makeTreasuresVisible(ArrayList<Treasure> t){
    
    }
    
    public void initGame(ArrayList<String> players){
    
    }
    
    public Player getCurrenPlayer(){
        return currentPlayer;
    }
    
    public Monster getCurrentMonster(){
        return currentMonster;
    }
    
    public boolean nextTurn(){
        return true;
    }
    
    public boolean endOfGame(CombatResult result){
        return true;
    }
}
