/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package napakalaki;

import java.util.ArrayList;

/**
 *
 * @author sergio
 */
public class BadConsequence {
    static final int MAXTREASURES = 10;
    
    private String text ;
    private int levels ;
    private int nVisibleTreasures ;
    private int nHiddenTreasures ;
    private boolean death;
    private ArrayList<TreasureKind> specificHiddenTreasures;
    private ArrayList<TreasureKind> specificVisibleTreasures;
    
    public BadConsequence(String texto, int niveles, int nVisible, int nHidden){
        text = texto;
        levels = niveles;
        nVisibleTreasures = nVisible;
        nHiddenTreasures = nHidden;
        death = false;
        specificVisibleTreasures = new ArrayList();
        specificHiddenTreasures = new ArrayList();
    }
    
    public BadConsequence(String texto, boolean muerte){
        text = texto;
        death = muerte;
        levels = -1;
        nVisibleTreasures = -1;
        nHiddenTreasures = -1;
        specificVisibleTreasures = new ArrayList();
        specificHiddenTreasures = new ArrayList();
    }
    
    public BadConsequence(String texto, int niveles, ArrayList<TreasureKind> specificV, ArrayList<TreasureKind> specificH){
        text = texto;
        levels = niveles;
        specificVisibleTreasures = specificV;
        specificHiddenTreasures = specificH;
        nVisibleTreasures = -1;
        nHiddenTreasures = -1;
        death = false;
    }
    
    public boolean isEmpty(){
        boolean vacio = false;
        
        if(nVisibleTreasures == 0 && nHiddenTreasures == 0 && specificVisibleTreasures.size() == 0){
            vacio = true;
        }
        else if(specificVisibleTreasures.size() == 0 && specificHiddenTreasures.size() == 0 && nVisibleTreasures == -1){
            vacio = true;
        }
        
        return vacio;
    } 
    
    public int getLevel(){
        return levels;
    }
    
    public int getnVisibleTreasures(){
        return nVisibleTreasures;
    }
    
    public int getnHiddenTreasures(){
        return nHiddenTreasures;
    }
    
    public ArrayList<TreasureKind> getSpecificVisible(){
        return specificVisibleTreasures;
    }
    
    public ArrayList<TreasureKind> getSpecificHidden(){
        return specificHiddenTreasures;
    }
    
    public void substractVisibleTreasure(Treasure t){
    
    }
    
    public void substractHiddenTreasure(Treasure t){
    
    }
    
    public BadConsequence adjustToFitTreasureLists(ArrayList<TreasureKind> v, ArrayList<TreasureKind> h){
        BadConsequence b=new BadConsequence("",0,0,0);
        
        return b;
    }
    
    public String toString(){
        return "Text = " + text + "\nLevels = " + Integer.toString(levels) 
             + "\nnVisibleTreasures = " + Integer.toString(nVisibleTreasures) 
             + "\nnHiddenTreasures = " + Integer.toString(nHiddenTreasures) 
             + "\nDeath = " + Boolean.toString(death) 
             + "\nSpecificVisibleTreasures = "+ specificVisibleTreasures.toString() 
             + "\nSpecificHiddenTreasures ="+ specificHiddenTreasures.toString() ;
    }
}
