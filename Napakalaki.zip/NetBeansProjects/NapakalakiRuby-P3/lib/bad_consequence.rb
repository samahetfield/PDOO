# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative 'player.rb'
require_relative 'treasure_kind.rb'
require_relative 'combat_result.rb'
require_relative 'monster.rb'
require_relative 'card_dealer.rb'
require 'singleton'

module NapakalakiGame
class BadConsequence
  attr_reader :text, :levels, :nVisibleTreasures, :nHiddenTreasures, :death, :specificHiddenTreasures, :specificVisibleTreasures;
  private_class_method :new
  
  @@MAXTREASURES = 10
  def initialize(aText, some_levels, some_visible_treasures, some_hidden_treasures, some_specific_visible_treasures, some_specific_hidden_treasures, death)
    @text = aText
    @levels = some_levels
    @nVisibleTreasures = some_visible_treasures
    @nHiddenTreasures = some_hidden_treasures
    @death = death
    @specificHiddenTreasures = some_specific_hidden_treasures
    @specificVisibleTreasures = some_specific_visible_treasures
  end
  
  def BadConsequence.newLevelNumberOfTreasures(aText, some_levels, some_visible_treasures, some_hidden_treasures)
    new(aText, some_levels, some_visible_treasures, some_hidden_treasures, [], [], false)
  end
  
  def BadConsequence.newLevelSpecificTreasures(aText, some_levels, some_specific_visible_treasures, some_specific_hidden_treasures)
    new(aText, some_levels, -1, -1, some_specific_visible_treasures, some_specific_hidden_treasures, false)
  end
  
  def BadConsequence.newDeath(aText)
    new(aText,Player.MAXLEVEL , @@MAXTREASURES, @@MAXTREASURES, [], [], true)
  end
  
  def isEmpty
    vacio = false
    if @nVisibleTreasures == 0 && @nHiddenTreasures == 0 && @specificVisibleTreasures.size == 0
      vacio = true
    else
      if @nVisibleTreasures == -1 && @specificVisibleTreasures.size == 0 && @specificHiddenTreasures.size == 0
        vacio = true
      else
        if @nVisibleTreasures == @@MAXTREASURES && @levels == Player.MAXLEVEL
          vacio = true
        end
      end
    end
    
    vacio
  end
  
  def substractVisibleTreasure(t)
    if @nVisibleTreasures != -1 && @nVisibleTreasures > 0
      @nVisibleTreasures = @nVisibleTreasures -1
    else
      @specificVisibleTreasures.delete(t.type)
    end    
  end
  
  def substractHiddenTreasure(t)
    if @nHiddenTreasures != -1 && @nHiddenTreasures > 0
      @nHiddenTreasures = @nHiddenTreasures -1
    else
      @specificHiddenTreasures.delete(t.type)
    end
  end
  
  def adjustToFitTreasureList(v,h)
    remove = false
    i=0
    visible = Array.new
    hidden = Array.new
    
    if @nVisibleTreasures != -1 && @specificVisibleTreasures.size == 0
      while i<v.size
        visible << v.at(i).type
        i = i+1
      end

      i=0

      while i<h.size
        hidden << h.at(i).type
        i = i+1
      end

        nV = @nVisibleTreasures
        nH = @nHiddenTreasures
        if v.size > @nVisibleTreasures
          nV = 0;

        else
          nV = v.size();

        end
        if h.size() > @nHiddenTreasures
          nH = 1;

        else
          nH = h.size();

        end

      bc = BadConsequence.newLevelNumberOfTreasures("",0, nV, nH)
    else
          while i<v.size
      visible << v.at(i).type
      i = i+1
    end
      
    i=0
      
    while i<h.size
      hidden << h.at(i).type
      i = i+1
    end
   
      i=0
      while i<v.size
        remove = false
        j=0
        while (j < @specificVisibleTreasures.size)&& (!remove)
          
          if @specificVisibleTreasures.at(j) == v.at(i).type
            visible.delete(v.at(i))
            remove = true
          end
          
          j=j+1
        end
        
        i = i+1
      end
      
      while i<h.size
        remove = false
        j=0
        while (j < @specificHiddenTreasures.size)&& (!remove)
          if @specificHiddenTreasures.at(j) == h.at(i).type
            hidden.delete(h.at(i))
          end
          
          j=j+1
        end
        
        i = i+1
      end
      
      bc= BadConsequence.newLevelSpecificTreasures("", -1 , visible, hidden)
    end
    
    bc
  end
  
  def to_s
    "Name: #{@text} \n Levels: #{@levels} \n nVisibleTreasures: #{@nVisibleTreasures} \n nHiddenTreasures: #{@nHiddenTreasures} \n Death: #{@death} \n SpecificVisibleTreasures: #{@specificVisibleTreasures} \n SpecificHiddenTreasures: #{@specificHiddenTreasures}"
  end 
end
end