# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative "bad_consequence.rb"
require_relative "monster.rb"
require_relative "prize.rb"

class PruebaNapakalaki
      @@monsters = Array.new
  
  
  def PruebaNapakalaki.combatLevel10(m)
    salida = Array.new
    m.each do |mons|
      if mons.combatLevel > 10
        salida << mons
      end
    end
    
    salida
  end
  
  def PruebaNapakalaki.soloPerdidaNiveles(m)
    salida = Array.new
    
    m.each do |mons|
      if mons.badConsequence.levels > 0 && mons.badConsequence.nVisibleTreasures == 0 && mons.badConsequence.nHiddenTreasures == 0 && mons.badConsequence.specificHiddenTreasures.size == 0 && mons.badConsequence.specificVisibleTreasures.size == 0
        salida << mons
      end
    end
    
    salida
  end
  
  def PruebaNapakalaki.buenRolloMayorA1(m)
    salida = Array.new
    
    m.each do |mons|
      if mons.prize.level > 1
        salida << mons
      end
    end
    
    salida
  end
  
  def PruebaNapakalaki.perdidaSpecific(m, t)
    salida = Array.new
    encontrado = false
    
    m.each do |mons|
      encontrado = false
      visible = mons.badConsequence.specificVisibleTreasures
      hidden = mons.badConsequence.specificHiddenTreasures
      
      visible.each do |tv|
        if tv == t && !encontrado
          salida << mons
          encontrado = true
        end
      end
      
      hidden.each do |th|
        if th == t && !encontrado
          salida << mons
          encontrado = true
        end
      end
      
    end
    
    salida
  end
  
    #Monstruo 1

     prize = Prize.new(2,1) 
     badConsequence = BadConsequence.newLevelSpecificTreasures('Pierdes tu armadura visible y otra oculta', 0,[TreasureKind::ARMOR], [TreasureKind::ARMOR]) 
     @@monsters << Monster.new('3 Byakhees de Bonanza', 8, prize, badConsequence) 

     #Monstruo 2

     prize = Prize.new(1,1) 
     badConsequence = BadConsequence.newLevelSpecificTreasures('Embobados con el lindo primigenio te descartas de tu casco visible', 0,[TreasureKind::HELMET], []) 
     @@monsters << Monster.new('Tenochtitlan', 2, prize, badConsequence) 

     #Monstruo 3

     prize = Prize.new(1,1) 
     badConsequence = BadConsequence.newLevelSpecificTreasures('El primordial bostezo contagioso. Pierdes el calzado visible', 0,[TreasureKind::SHOES], []) 
     @@monsters << Monster.new('El sopor de Dunwich', 2, prize, badConsequence) 

     #Monstruo 4

     prize = Prize.new(4,1) 
     badConsequence = BadConsequence.newLevelSpecificTreasures('Te atrapan para llevarte de fiesta y te dejan caer en mitad del vuelo. Descarta 1 mano visible y 1 mano oculta', 0,[TreasureKind::ONEHAND], [TreasureKind::ONEHAND]) 
     @@monsters << Monster.new('Demonios de Magaluf', 2, prize, badConsequence) 

     #Monstruo 5

     prize = Prize.new(3,1) 
     badConsequence = BadConsequence.newLevelNumberOfTreasures('Pierdes todos tus tesoros visibles', 0,5,0) 
     @@monsters << Monster.new('El gorron en el umbral', 13, prize, badConsequence) 

     ## Monstruo 6

     prize = Prize.new(2,1) 
     badConsequence = BadConsequence.newLevelSpecificTreasures('Pierdes la armadura visible', 0,[TreasureKind::ARMOR], []) 
     @@monsters << Monster.new('H.P. Munchcraft', 6, prize, badConsequence) 

     ## Monstruo 7

     prize = Prize.new(1,1) 
     badConsequence = BadConsequence.newLevelSpecificTreasures('Sientes bichos bajo la ropa. Descarta la armadura visible', 0,[TreasureKind::ARMOR], []) 
     @@monsters << Monster.new('Necrofago', 13, prize, badConsequence) 

     ## Monstruo 8

     prize = Prize.new(3,2) 
     badConsequence = BadConsequence.newLevelNumberOfTreasures('Pierdes 5 niveles y 3 tesoros visibles', 5,3,0) 
     @@monsters << Monster.new('El rey de rosado',11, prize, badConsequence)

     ## Monstruo 9

     prize = Prize.new(1,1) 
     badConsequence = BadConsequence.newLevelNumberOfTreasures('Toses los pulmones y pierdes 2 niveles', 2,0,0) 
     @@monsters << Monster.new('Flecher', 2, prize, badConsequence)

     #Monstruo 10

     prize = Prize.new(2,1) 
     badConsequence = BadConsequence.newDeath('Estos monstruos resultan bastante superficiales y te aburren mortalmente. Estas muerto') 
     @@monsters << Monster.new('Los hondos', 8, prize, badConsequence) 

     #Monstruo 11

     prize = Prize.new(2,1) 
     badConsequence = BadConsequence.newLevelNumberOfTreasures('Pierdes 2 niveles y 2 tesoros ocultos',2,0,2) 
     @@monsters << Monster.new('Semillas Cthulhu', 4, prize, badConsequence) 

     #Monstruo 12

     prize = Prize.new(2,1) 
     badConsequence = BadConsequence.newLevelNumberOfTreasures('Te intentas escaquear. Pierdes una mano visible',0,[TreasureKind::ONEHAND],[]) 
     @@monsters << Monster.new('Dameargo', 1, prize, badConsequence) 

     #Monstruo 13

     prize = Prize.new(2,1) 
     badConsequence = BadConsequence.newLevelNumberOfTreasures('Da mucho asquito. Pierdes 3 niveles',3,0,0) 
     @@monsters << Monster.new('Pollipolipo volante', 3, prize, badConsequence) 

     #Monstruo 14

     prize = Prize.new(3,1) 
     badConsequence = BadConsequence.newDeath('No le hace gracia que pronuncien mal su nombre. Estas muerto') 
     @@monsters << Monster.new('Yskhtihyssg-Goth', 14, prize, badConsequence) 

     #Monstruo 15

     prize = Prize.new(3,1) 
     badConsequence = BadConsequence.newDeath('La familia te atrapa.Estas muerto') 
     @@monsters << Monster.new('Familia feliz', 1, prize, badConsequence) 

     #Monstruo 16

     prize = Prize.new(2,1) 
     badConsequence = BadConsequence.newLevelSpecificTreasures('La quinta directiva primaria te oblga a perder 2 niveles y un tesoro 2 manos visibles',2,[TreasureKind::BOTHHANDS], []) 
     @@monsters << Monster.new('Roboggoth', 13, prize, badConsequence) 

     #Monstruo 17

     prize = Prize.new(1,1) 
     badConsequence = BadConsequence.newLevelSpecificTreasures('Te asusta en la noche. Pierdes un casco visible',0,[TreasureKind::HELMET],[]) 
     @@monsters << Monster.new('El espia sordo', 5, prize, badConsequence) 

     #Monstruo 18

     prize = Prize.new(2,1) 
     badConsequence = BadConsequence.newLevelNumberOfTreasures('Menudo susto te llevas. Pierdes 2 niveles y 5 tesoros visibles',2,5,0) 
     @@monsters << Monster.new('Tongue', 19, prize, badConsequence) 

     #Monstruo 19

     prize = Prize.new(2,1) 
     badConsequence = BadConsequence.newLevelSpecificTreasures('Te faltan manos para tanta cabeza. Pierdes 3 niveles y tus tesoros visibles de las manos', 3,[TreasureKind::ONEHAND , TreasureKind::ONEHAND ,TreasureKind::BOTHHANDS], []) 
     @@monsters << Monster.new('Bicefalo', 21, prize, badConsequence) 
     
     puts "\nMonstruos con combatLevel > 10\n"
  
     sal = PruebaNapakalaki.combatLevel10(@@monsters)
     sal.each do |element|
       puts element.to_s
     end
     
     puts "\nMonstruos con mal rollo solo perdida niveles\n"
    
     sal = PruebaNapakalaki.soloPerdidaNiveles(@@monsters)
     sal.each do |element|
       puts element.to_s
     end
     
     puts "\nBuen rollo con ganancia de niveles > 1\n"
     
     sal = PruebaNapakalaki.buenRolloMayorA1(@@monsters)
     sal.each do |element|
       puts element.to_s
     end
     
     puts "\nPerdida especifica de ARMOR\n"
     
     sal = PruebaNapakalaki.perdidaSpecific(@@monsters, TreasureKind::ARMOR)
     sal.each do |element|
       puts element.to_s
     end
     
     puts "\nPerdida especifica de ONEHAND\n"
     
     sal = PruebaNapakalaki.perdidaSpecific(@@monsters, TreasureKind::ONEHAND)
     sal.each do |element|
       puts element.to_s
     end
     
     puts "\nPerdida especifica de BOTHHANDS\n"
     
     sal = PruebaNapakalaki.perdidaSpecific(@@monsters, TreasureKind::BOTHHANDS)
     sal.each do |element|
       puts element.to_s
     end
     
     puts "\nPerdida especifica de SHOES\n"
     
     sal = PruebaNapakalaki.perdidaSpecific(@@monsters, TreasureKind::SHOES)
     sal.each do |element|
       puts element.to_s
     end
     
     puts "\nPerdida especifica de HELMET\n"
     
     sal = PruebaNapakalaki.perdidaSpecific(@@monsters, TreasureKind::HELMET)
     sal.each do |element|
       puts element.to_s
     end
   
end 