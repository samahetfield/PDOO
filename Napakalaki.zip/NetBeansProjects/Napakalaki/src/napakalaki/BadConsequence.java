/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package napakalaki;

import java.util.ArrayList;

/**
 *
 * @author sergio
 */
public class BadConsequence {
    private String text ;
    private int levels ;
    private int nVisibleTreasures ;
    private int nHiddenTreasures ;
    private boolean death;
    private ArrayList<TreasureKind> specificHiddenTreasures;
    private ArrayList<TreasureKind> specificVisibleTreasures;
    
    public BadConsequence(String texto, int niveles, int nVisible, int nHidden){
        text = texto;
        levels = niveles;
        nVisibleTreasures = nVisible;
        nHiddenTreasures = nHidden;
        death = false;
        specificVisibleTreasures = new ArrayList();
        specificHiddenTreasures = new ArrayList();
    }
    
    public BadConsequence(String texto, boolean muerte){
        text = texto;
        death = muerte;
        levels = -1;
        nVisibleTreasures = -1;
        nHiddenTreasures = -1;
        specificVisibleTreasures = new ArrayList();
        specificHiddenTreasures = new ArrayList();
    }
    
    public BadConsequence(String texto, int niveles, ArrayList<TreasureKind> specificV, ArrayList<TreasureKind> specificH){
        text = texto;
        levels = niveles;
        specificVisibleTreasures = specificV;
        specificHiddenTreasures = specificH;
        nVisibleTreasures = -1;
        nHiddenTreasures = -1;
        death = false;
    }
    
    public String getText(){
        return text;
    }
    
    public int getLevel(){
        return levels;
    }
    
    public int getnVisibleTreasures(){
        return nVisibleTreasures;
    }
    
    public int getnHiddenTreasures(){
        return nHiddenTreasures;
    }
    public boolean getDeath(){
        return death;
    }
    
    public ArrayList<TreasureKind> getSpecificVisible(){
        return specificVisibleTreasures;
    }
    
    public ArrayList<TreasureKind> getSpecificHidden(){
        return specificHiddenTreasures;
    }
    
    public String toString(){
        return "Text = " + text + "\nLevels = " + Integer.toString(levels) 
             + "\nnVisibleTreasures = " + Integer.toString(nVisibleTreasures) 
             + "\nnHiddenTreasures = " + Integer.toString(nHiddenTreasures) 
             + "\nDeath = " + Boolean.toString(death) 
             + "\nSpecificVisibleTreasures = "+ specificVisibleTreasures.toString() 
             + "\nSpecificHiddenTreasures ="+ specificHiddenTreasures.toString() ;
    }
}
