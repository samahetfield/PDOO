# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative 'player.rb'
require_relative 'treasure_kind.rb'
require_relative 'combat_result.rb'
require_relative 'monster.rb'
require_relative 'card_dealer.rb'
require 'singleton'

module NapakalakiGame
class BadConsequence
  attr_reader :text, :levels, :nVisibleTreasures, :nHiddenTreasures, :death, :specificHiddenTreasures, :specificVisibleTreasures, :MAXTREASURES
  
  @@MAXTREASURES = 10
  def initialize(aText, some_levels)
    @text = aText
    @levels = some_levels
  end
  
#  def BadConsequence.newLevelNumberOfTreasures(aText, some_levels, some_visible_treasures, some_hidden_treasures)
#    new(aText, some_levels, some_visible_treasures, some_hidden_treasures, [], [], false)
#  end
#  
#  def BadConsequence.newLevelSpecificTreasures(aText, some_levels, some_specific_visible_treasures, some_specific_hidden_treasures)
#    new(aText, some_levels, -1, -1, some_specific_visible_treasures, some_specific_hidden_treasures, false)
#  end
#  
#  def BadConsequence.newDeath(aText)
#    new(aText,Player.MAXLEVEL , @@MAXTREASURES, @@MAXTREASURES, [], [], true)
#  end
  
  
  
  def BadConsequence.MAXTREASURES
    @@MAXTREASURES
  end
  
  def isEmpty
    raise 'Doh! Abstract method'
  end
  
  def substractVisibleTreasure(t)
     raise 'Doh!. Abstract method'  
  end
  
  def substractHiddenTreasure(t)
     raise 'Doh! Abstract method'
  end
  
  def adjustToFitTreasureList(v,h)
     raise 'Doh!. ABstract method'
  end
  
  def to_s
    "Name: #{@text} \n Levels: #{@levels}"
  end 
end
end