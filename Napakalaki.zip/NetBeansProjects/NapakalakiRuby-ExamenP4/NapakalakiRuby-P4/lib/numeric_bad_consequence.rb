# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.
require_relative 'bad_consequence.rb'


module NapakalakiGame
class NumericBadConsequence < BadConsequence
  def initialize(text, level, nV, nH)
    super(text, level)
    @nVisibleTreasures = nV
    @nHiddenTreasures = nH
  end
  
  def getNVisible
    @nVisibleTreasures
  end
  
  def getNHidden
    @nHiddenTreasures
  end
  
  def isEmpty
    vacio = false
    if @nVisibleTreasures == 0 && @nHiddenTreasures == 0 
      vacio = true
    end
    
    vacio
  end
  
  def substractVisibleTreasure(t)
    if @nVisibleTreasures > 0
      @nVisibleTreasures = @nVisibleTreasures -1
    end
  end
  
  def substractHiddenTreasure(t)
    if @nHiddenTreasures > 0
      @nHiddenTreasures = @nHiddenTreasures -1
    end
  end
  
  def adjustToFitTreasureList(v,h)
    remove = false
    i=0
    visible = Array.new
    hidden = Array.new
    
      while i<v.size
        visible << v.at(i).type
        i = i+1
      end

      i=0

      while i<h.size
        hidden << h.at(i).type
        i = i+1
      end

        nV = @nVisibleTreasures
        nH = @nHiddenTreasures
        if v.size() > @nVisibleTreasures
          nV = 0;

        else
          nV = v.size();

        end
        if h.size() > @nHiddenTreasures
          nH = 0;

        else
          nH = h.size();

        end

      bc = NumericBadConsequence.new("",0, nV, nH)
   
    
      bc
  end
  
  def to_s
    super
    "nVisibleTreasures =#{@nVisibleTreasures} \n nHiddenTreasures =#{@nHiddenTreasures}"
  end
end
end