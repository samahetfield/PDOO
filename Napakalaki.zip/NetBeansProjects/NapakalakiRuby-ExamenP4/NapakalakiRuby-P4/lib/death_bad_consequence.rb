# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.
require_relative 'bad_consequence.rb'

module NapakalakiGame
class DeathBadConsequence < NumericBadConsequence
  def initialize(text, level, nV,nH, death)
    super(text,level,nV,nH)
    @death = death
  end
  
  def isEmpty
    vacio = false
        if @nVisibleTreasures == @@MAXTREASURES && @levels == Player.MAXLEVEL
          vacio = true
        end

    vacio
  end
  
  def substractVisibleTreasure(t)
    super
  end
  
  def substractHiddenTreasure(t)
    super
  end
  
  def adjustToFitTreasureList(v,h)
    super
  end
  
  def to_s
    super
    "Death =#{@death}"
  end
end
end