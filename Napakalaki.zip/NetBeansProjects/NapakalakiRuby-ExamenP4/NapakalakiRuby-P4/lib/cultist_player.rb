# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

module NapakalakiGame
  
class CultistPlayer < Player
  @@totalCultistPlayer = 0
  def initialize(p,c)
    super.copia(p)
    @myCultistCard = c
    @totalCultistPlayer = @totalCultistPlayer + 1
  end
  
  def shouldConvert
    false
  end
  
  def CultistPlayer.getTotalCultistPlayer
    @totalCultistPlayer
  end
  
  protected
  def getCombatLevel
    l = super.getCombat + super.getCombat*0.2
    
    c = @myCultistCard.getGainedLevels*@totalCultistPlayer
    
    total = l+c
    total
  end
  
  def getOponentLevel(m)
    m.getCombatLevelAgainstCultistPlayer
  end
  
  private
  def giveMeATreasure
    n = rand(@visibleTreasures.size)
    
    @visibleTreasures.at(n)
  end
  
  def canYouGiveMeATreasure
    puedo = false
    if super.enemy.visibleTreasures.size > 0
      puedo = true
    end
    
    puedo
  end
end
end