# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require 'bad_consequence.rb'


module NapakalakiGame
class SpecificBadConsequence < BadConsequence
  def initialize(text, level, sV,sH)
    super(text, level)
    @specificVisibleTreasures = sV
    @specificHiddenTreasures = sH
  end
  
  def isEmpty
    vacio = false
   
      if @specificVisibleTreasures.size == 0 && @specificHiddenTreasures.size == 0
        vacio = true
      
      end
    
    vacio
  end
  
  def substractVisibleTreasure(t)
      @specificVisibleTreasures.delete(t.type)
  end
  
  def substractHiddenTreasure(t)
      @specificHiddenTreasures.delete(t.type)
  end
  
  def adjustToFitTreasureList(v,h)
    remove = false
    i=0
    visible = Array.new
    hidden = Array.new
    pos_borrar_v = Array.new
    pos_borrar_h = Array.new

    while i<v.size
      visible << v.at(i).type
      i = i+1
    end
      
    i=0
      
    while i<h.size
      hidden << h.at(i).type
      i = i+1
    end
   
      i=0
      while i<v.size
        remove = false
        j=0
        while (j < @specificVisibleTreasures.size)
          
          if @specificVisibleTreasures.at(j) == v.at(i).type
            pos_borrar_v << i
          end
          
          j=j+1
        end
        
        i = i+1
      end
      
      while i<h.size
        remove = false
        j=0
        while (j < @specificHiddenTreasures.size)
          if @specificHiddenTreasures.at(j) == h.at(i).type
            pos_borrar_h << i
          end
          
          j=j+1
        end
        
        i = i+1
      end
      
      borrar = true
      
    i=0
    j=0
    
    while i < v.size
      borrar = true
      j=0
      while j < pos_borrar_v.size
        if i == pos_borrar_v.at(j)
          borrar = false
        end
        
        j = j+1
      end
      if borrar
        visible.delete(v.at(i).type)
      end
      i = i+1
    end
    
    borrar = true
    i=0
    while i < h.size
      borrar = true
      j=0
      while j < pos_borrar_h.size
        if i == pos_borrar_h.at(j)
          borrar = false
        end
        
        j = j+1
      end
      if borrar
        hidden.delete(h.at(i).type)
      end
      i = i+1
    end
      
      bc= SpecificBadConsequence.new("", -1 , visible, hidden)
    
    
    bc
end
  
end
end
