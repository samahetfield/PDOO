# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.


require_relative 'treasure.rb'
require_relative 'treasure_kind.rb'
require_relative 'monster.rb'
require_relative 'bad_consequence.rb'
require_relative 'specific_bad_consequence.rb'
require_relative 'numeric_bad_consequence.rb'
require_relative 'death_bad_consequence.rb'
require_relative 'cultist'
require 'singleton'

module NapakalakiGame
class CardDealer
  include Singleton  
  @@instance=nil
  private
  def initialize
      @usedMonsters = Array.new
      @unusedMonsters = Array.new
      @unusedTreasures = Array.new
      @usedTreasures = Array.new
      @unusedCultist = Array.new
  end
  
  def initTreasureCardDeck
    @unusedTreasures << Treasure.new("Si mi amo", 4, TreasureKind::HELMET)
    @unusedTreasures << Treasure.new("Botas de investigacion", 3, TreasureKind::SHOES)
    @unusedTreasures << Treasure.new("Capucha Cthulhu", 3, TreasureKind::HELMET)
    @unusedTreasures << Treasure.new("A prueba de babas", 2, TreasureKind::ARMOR)
    @unusedTreasures << Treasure.new("Botas de llucia acida", 1, TreasureKind::BOTHHANDS)
    @unusedTreasures << Treasure.new("Casco minero", 2, TreasureKind::HELMET)
    @unusedTreasures << Treasure.new("Ametralladora ACME", 4, TreasureKind::BOTHHANDS)
    @unusedTreasures << Treasure.new("Camiseta de la ETSIIT", 1, TreasureKind::ARMOR)
    @unusedTreasures << Treasure.new("Clavo de rail ferroviario", 3, TreasureKind::ONEHAND)
    @unusedTreasures << Treasure.new("Cuchillo de sushi arcano", 2, TreasureKind::ONEHAND)
    @unusedTreasures << Treasure.new("Fez alopodo", 3, TreasureKind::HELMET)
    @unusedTreasures << Treasure.new("Hacha prehistorica", 2, TreasureKind::ONEHAND)
    @unusedTreasures << Treasure.new("El aparato del Pr. Tesla", 4, TreasureKind::ARMOR)
    @unusedTreasures << Treasure.new("Gaita", 4, TreasureKind::BOTHHANDS)
    @unusedTreasures << Treasure.new("Insecticida", 2, TreasureKind::ONEHAND)
    @unusedTreasures << Treasure.new("Escopeta de 3 canones", 4, TreasureKind::BOTHHANDS)
    @unusedTreasures << Treasure.new("Garabato mistico", 2, TreasureKind::ONEHAND)
    @unusedTreasures << Treasure.new("La rebeca metalica", 2, TreasureKind::ARMOR)
    @unusedTreasures << Treasure.new("Lanzallamas", 4, TreasureKind::BOTHHANDS)
    @unusedTreasures << Treasure.new("Necro-comicon", 1, TreasureKind::ONEHAND)
    @unusedTreasures << Treasure.new("Necronomicon", 5, TreasureKind::BOTHHANDS)
    @unusedTreasures << Treasure.new("Linterna a 2 manos", 3, TreasureKind::BOTHHANDS)
    @unusedTreasures << Treasure.new("Necro-gnomicon", 2, TreasureKind::ONEHAND)
    @unusedTreasures << Treasure.new("Necrotelecom", 2, TreasureKind::HELMET)
    @unusedTreasures << Treasure.new("Mazo de los antiguos", 3, TreasureKind::ONEHAND)
    @unusedTreasures << Treasure.new("Necro-playboycon", 3, TreasureKind::ONEHAND)
    @unusedTreasures << Treasure.new("Porra preternatural", 2, TreasureKind::ONEHAND)
    @unusedTreasures << Treasure.new("Shogulador", 1, TreasureKind::BOTHHANDS)
    @unusedTreasures << Treasure.new("Varita de atizamiento", 3, TreasureKind::ONEHAND)
    @unusedTreasures << Treasure.new("Tentaculo de pega", 2, TreasureKind::HELMET)
    @unusedTreasures << Treasure.new("Zapato deja-amigos", 1, TreasureKind::SHOES)
    
    
  end
  
  def initMonsterCardDeck
     #Monstruo 1

     prize = Prize.new(2,1) 
     badConsequence = SpecificBadConsequence.new('Pierdes tu armadura visible y otra oculta', 0,[TreasureKind::ARMOR], [TreasureKind::ARMOR]) 
     @unusedMonsters << Monster.new('3 Byakhees de Bonanza', 8, prize, badConsequence,0) 

     #Monstruo 2

     prize = Prize.new(1,1) 
     badConsequence =SpecificBadConsequence.new('Embobados con el lindo primigenio te descartas de tu casco visible', 0,[TreasureKind::HELMET], []) 
     @unusedMonsters << Monster.new('Tenochtitlan', 2, prize, badConsequence,0) 

     #Monstruo 3

     prize = Prize.new(1,1) 
     badConsequence = SpecificBadConsequence.new('El primordial bostezo contagioso. Pierdes el calzado visible', 0,[TreasureKind::SHOES], []) 
     @unusedMonsters << Monster.new('El sopor de Dunwich', 2, prize, badConsequence,0) 

     #Monstruo 4

     prize = Prize.new(4,1) 
     badConsequence = SpecificBadConsequence.new('Te atrapan para llevarte de fiesta y te dejan caer en mitad del vuelo. Descarta 1 mano visible y 1 mano oculta', 0,[TreasureKind::ONEHAND], [TreasureKind::ONEHAND]) 
     @unusedMonsters << Monster.new('Demonios de Magaluf', 2, prize, badConsequence,0) 

     #Monstruo 5

     prize = Prize.new(3,1) 
     badConsequence = NumericBadConsequence.new('Pierdes todos tus tesoros visibles', 0,BadConsequence.MAXTREASURES,0) 
     @unusedMonsters << Monster.new('El gorron en el umbral', 13, prize, badConsequence,0) 

     ## Monstruo 6

     prize = Prize.new(2,1) 
     badConsequence = SpecificBadConsequence.new('Pierdes la armadura visible', 0,[TreasureKind::ARMOR], []) 
     @unusedMonsters << Monster.new('H.P. Munchcraft', 6, prize, badConsequence,0) 

     ## Monstruo 7

     prize = Prize.new(1,1) 
     badConsequence = SpecificBadConsequence.new('Sientes bichos bajo la ropa. Descarta la armadura visible', 0,[TreasureKind::ARMOR], []) 
     @unusedMonsters << Monster.new('Necrofago', 13, prize, badConsequence,0) 

     ## Monstruo 8

     prize = Prize.new(3,2) 
     badConsequence = NumericBadConsequence.new('Pierdes 5 niveles y 3 tesoros visibles', 5,3,0) 
     @unusedMonsters << Monster.new('El rey de rosado',11, prize, badConsequence,0)

     ## Monstruo 9

     prize = Prize.new(1,1) 
     badConsequence = NumericBadConsequence.new('Toses los pulmones y pierdes 2 niveles', 2,0,0) 
     @unusedMonsters << Monster.new('Flecher', 2, prize, badConsequence,0)

     #Monstruo 10

     prize = Prize.new(2,1) 
     badConsequence = DeathBadConsequence.new('Estos monstruos resultan bastante superficiales y te aburren mortalmente. Estas muerto', Player.MAXLEVEL, BadConsequence.MAXTREASURES, BadConsequence.MAXTREASURES, true) 
     @unusedMonsters << Monster.new('Los hondos', 8, prize, badConsequence,0) 

     #Monstruo 11

     prize = Prize.new(2,1) 
     badConsequence = NumericBadConsequence.new('Pierdes 2 niveles y 2 tesoros ocultos',2,0,2) 
     @unusedMonsters << Monster.new('Semillas Cthulhu', 4, prize, badConsequence,0) 

     #Monstruo 12

     prize = Prize.new(2,1) 
     badConsequence = NumericBadConsequence.new('Te intentas escaquear. Pierdes una mano visible',0,[TreasureKind::ONEHAND],[]) 
     @unusedMonsters << Monster.new('Dameargo', 1, prize, badConsequence,0) 

     #Monstruo 13

     prize = Prize.new(2,1) 
     badConsequence = NumericBadConsequence.new('Da mucho asquito. Pierdes 3 niveles',3,0,0) 
     @unusedMonsters << Monster.new('Pollipolipo volante', 3, prize, badConsequence,0) 

     #Monstruo 14

     prize = Prize.new(3,1) 
     badConsequence = DeathBadConsequence.new('No le hace gracia que pronuncien mal su nombre. Estas muerto', Player.MAXLEVEL, BadConsequence.MAXTREASURES, BadConsequence.MAXTREASURES, true) 
     @unusedMonsters << Monster.new('Yskhtihyssg-Goth', 14, prize, badConsequence,0) 

     #Monstruo 15

     prize = Prize.new(3,1) 
     badConsequence = DeathBadConsequence.new('La familia te atrapa.Estas muerto', Player.MAXLEVEL, BadConsequence.MAXTREASURES, BadConsequence.MAXTREASURES, true) 
     @unusedMonsters << Monster.new('Familia feliz', 1, prize, badConsequence,0) 

     #Monstruo 16

     prize = Prize.new(2,1) 
     badConsequence = SpecificBadConsequence.new('La quinta directiva primaria te oblga a perder 2 niveles y un tesoro 2 manos visibles',2,[TreasureKind::BOTHHANDS], []) 
     @unusedMonsters << Monster.new('Roboggoth', 13, prize, badConsequence,0) 

     #Monstruo 17

     prize = Prize.new(1,1) 
     badConsequence = SpecificBadConsequence.new('Te asusta en la noche. Pierdes un casco visible',0,[TreasureKind::HELMET],[]) 
     @unusedMonsters << Monster.new('El espia sordo', 5, prize, badConsequence,0) 

     #Monstruo 18

     prize = Prize.new(2,1) 
     badConsequence =NumericBadConsequence.new('Menudo susto te llevas. Pierdes 2 niveles y 5 tesoros visibles',2,5,0) 
     @unusedMonsters << Monster.new('Tongue', 19, prize, badConsequence,0) 

     #Monstruo 19

     prize = Prize.new(2,1) 
     badConsequence = SpecificBadConsequence.new('Te faltan manos para tanta cabeza. Pierdes 3 niveles y tus tesoros visibles de las manos', 3,[TreasureKind::ONEHAND , TreasureKind::ONEHAND ,TreasureKind::BOTHHANDS], []) 
     @unusedMonsters << Monster.new('Bicefalo', 21, prize, badConsequence,0) 
     
    
    #Monstruos sectarios
     
     prize = Prize.new(3,1) 
     badConsequence = SpecificBadConsequence.new('Pierdes una mano visible', 0,[TreasureKind::ONEHAND], []) 
     @unusedMonsters << Monster.new('El mal indecible impronunciable', 10, prize, badConsequence,-2)
     
     prize = Prize.new(2,1) 
     badConsequence = NumericBadConsequence.new('Pierdes tus tesoros visibles. Jajaja', 0, BadConsequence.MAXTREASURES, 0) 
     @unusedMonsters << Monster.new('Testigos oculares', 6, prize, badConsequence,+2) 
     
     prize = Prize.new(2,5) 
     badConsequence = DeathBadConsequence.new('Hoy no es tu dia de suerte. Mueres', Player.MAXLEVEL, BadConsequence.MAXTREASURES, BadConsequence.MAXTREASURES, true) 
     @unusedMonsters << Monster.new('El gran Ctulhu', 20, prize, badConsequence,+4)
     
     prize = Prize.new(2,1) 
     badConsequence = NumericBadConsequence.new('Tu gobierno te recorta 2 niveles', 2,0,0) 
     @unusedMonsters << Monster.new('Serpiente politico', 8, prize, badConsequence,-2) 
     
     prize = Prize.new(1,1) 
     badConsequence = SpecificBadConsequence.new('Pierdes tu casco y tu armadura visivble. Pierdes tus manos ocultas', 0,[TreasureKind::HELMET , TreasureKind::ARMOR], [TreasureKind::ONEHAND, TreasureKind::ONEHAND, TreasureKind::BOTHHANDS]) 
     @unusedMonsters << Monster.new('Felpugooth', 2, prize, badConsequence,+5)
     
     prize = Prize.new(4,2) 
     badConsequence = NumericBadConsequence.new('Pierdes 2 niveles', 2,0,0) 
     @unusedMonsters << Monster.new('Shogooth', 16, prize, badConsequence,-4) 
     
     prize = Prize.new(1,1) 
     badConsequence = NumericBadConsequence.new('Pintalabios negro. Pierdes 2 niveles', 2,0,0) 
     @unusedMonsters << Monster.new('Lolitagooth', 2, prize, badConsequence,+3) 
     
    
  end
  
  def shuffleTreasures
    @unusedTreasures.shuffle!
  end
  
  def shuffleMonsters
    @unusedMonsters.shuffle!
  end
  
  def shuffleCultist
    @unusedCultist.shuffle!
  end
  
  def initCultistCardDeck
    @unusedCultist << Cultist.new("Sectario", +1)
    @unusedCultist << Cultist.new("Sectario", +2)
    @unusedCultist << Cultist.new("Sectario", +1)
    @unusedCultist << Cultist.new("Sectario", +2)
    @unusedCultist << Cultist.new("Sectario", +1)
    @unusedCultist << Cultist.new("Sectario", +1)
  end
  
  public
  def CardDealer.getInstance
    CardDealer.instance
  end
  
  def nextTreasure
    if @unusedTreasures.size == 0
      @unusedTreasures = @usedTreasures
      @usedTreasures.clear
      shuffleTreasures
    end
    
    tesoro = @unusedTreasures.at(0)
    @usedTreasures << tesoro
    @unusedTreasures.delete(tesoro)
    
    tesoro
  end
  
  def nextMonster
    if @unusedMonsters.size == 0
      @unusedMonsters = @usedMonsters
      @usedMonsters.clear
      shuffleMonsters
    end
    
    monster = @unusedMonsters.at(0)
    @usedMonsters << monster
    @unusedMonsters.delete(monster)
    
    monster
    
  end
  
  def nextCultist
    
  end
  def giveTreasureBack(t)
    @usedTreasures << t
    
    @unusedTreasures.delete(t)
  end
  
  def giveMonsterBack(m)
    @usedMonsters << m
    
    @unusedMonsters.delete(m)
  end
  
  def initCards
    initTreasureCardDeck
    initMonsterCardDeck
    initCultistCardDeck
    
    shuffleCultist
    shuffleMonsters
    shuffleTreasures
  end
  
end
end