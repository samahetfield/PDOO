# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative 'player.rb'
require_relative 'combat_result.rb'
require_relative 'monster.rb'
require_relative 'card_dealer.rb'
require 'singleton'

module NapakalakiGame
class Napakalaki
  attr_reader :currentPlayer, :currentMonster
  include Singleton
  @@instance = nil
  
  private
  def initialize
    @currentPlayer = Player.new("")
    @players = Array.new
    @dealer = CardDealer.getInstance
    @currentMonster = Monster.new("", 0, nil, nil,0)
  end
  
  def initPlayers(names)
    i = 0
    
    while i < names.size
      p = Player.new(names.at(i))
      @players << p
      
      i = i+1
    end
  end
  
  def nextPlayer
    cambiado = false
    if @currentPlayer.name == ""
      @currentPlayer = @players.at(rand(@players.size))
    else
      i = 0
      while(i<@players.size && !cambiado)
        if @players.at(i) == @currentPlayer
          @currentPlayer = @players.at((i+1) % (@players.size))
          cambiado = true
        end
        i = i+1
      end
    end
    
    @currentPlayer
  end
  
  def nextTurnAllowed
    if @currentPlayer.name == ""
      puedo = true
    else
      puedo = @currentPlayer.validState
    end
    
    puedo
  end
  
  def setEnemies
    i = 0
    
    while i < @players.size
      p = @players.at(i)
      
      number = 0
      while(number == i)
        number = rand(@players.size)
      end
      p.setEnemy(@players.at(number))
      i = i+1
    end
  end
  
  public
  def Napakalaki.getInstance
    Napakalaki.instance
  end
  
  def developCombat
    m = @currentMonster
    
    cr =@currentPlayer.combat(m)
    
    if cr == CombatResult::LOSEANDCONVERT
      c = @dealer.nextCultist
      cp = CultistPlayer.new(@currentPlayer, c)
      
      
      cp.setEnemy(@currentPlayer.enemy)
      @players.delete(@currentPlayer)
      @players << cp
      @currentPlayer = cp
    end
    
    @dealer.giveMonsterBack(m)
    
    cr
  end
  
  def discardVisibleTreasures(t)
    i = 0
    
    while i < t.size
      treasure = t.at(i)
      
      @currentPlayer.discardVisibleTreasure(treasure)
      
      @dealer.giveTreasureBack(t)
      
      i = i+1
    end
  end
  
  def discardHiddenTreasures(t)
    i = 0
    
    while i < t.size
      treasure = t.at(i)
      
      @currentPlayer.discardHiddenTreasure(treasure)
      
      @dealer.giveTreasureBack(t)
      
      i = i+1
    end
  end
  
  def makeTreasuresVisible(t)
    i=0
    
    while i < t.size
      tr = t.at(i)
      
      @currentPlayer.makeTreasureVisible(tr)
      
      i = i+1
    end
  end
  
  def initGame(players)
    initPlayers(players)
    setEnemies
    @dealer.initCards
    nextTurn
  end
  
  def nextTurn
    stateOk = nextTurnAllowed
    
    if stateOk
      @currentMonster = @dealer.nextMonster
      @currentPlayer = nextPlayer
      dead = @currentPlayer.isDead
      
      if dead
        @currentPlayer.initTreasures
      end
    end
    
    stateOk
  end
  
  def endOfGame(result)
    if result == CombatResult::WINGAME
      fin = true
    else
      fin = false
    end
    
    fin
  end
  
  def getCurrentPlayer
    @currentPlayer
  end
  
  def getCurrentMonster
    @currentMonster
  end
end
end