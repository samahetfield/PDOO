# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

module NapakalakiGame

class CrazyPlayer < CultistPlayer
  def initialize(p, c, m)
    super(p,c)
    @madnessLevel = m
  end
  
  def getCombatLevel
    level = 0
    
    level
  end
  
  def do_crazy
    total = super.getCombatLevel
    
    i=0
    
    while i< total
      puts "ASDABLDFSGAJI9GAGASDG"
      i = i+1
    end
  end
end
end
