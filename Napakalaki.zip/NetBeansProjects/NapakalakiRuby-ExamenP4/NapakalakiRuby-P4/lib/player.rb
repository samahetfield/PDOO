# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative 'treasure.rb'
require_relative 'bad_consequence.rb'
require_relative 'card_dealer.rb'
require_relative 'dice.rb'
require_relative 'combat_result.rb'

module NapakalakiGame
class Player
  attr_reader :name, :visibleTreasures, :hiddenTreasures, :level, :canISteal, :MAXLEVEL, :enemy, :pendingBadConsequence
  
  @@MAXLEVEL = 10
  def initialize(name)
    @name = name
    @level = 0
    @dead = true
    @canISteal = true 
    @enemy = nil
    @visibleTreasures = Array.new
    @hiddenTreasures = Array.new
    @pendingBadConsequence = nil
  end
  
  def copia(p)
    @name = p.name
    @level = p.level
    @dead = p.isDead
    @canISteal = p.canISteal
    @enemy = p.enemy
    @visibleTreasures = p.visibleTreasures
    @hiddenTreasures = p.hiddenTreasures
    @pendingBadConsequence = p.pendingBadConsequence
  end
  
  protected
  def getOponentLevel(m)
    m.getCombatLevel
  end
  
  def shouldConvert
    puedo = false
    dice = Dice.getInstance
    
    n = dice.nextNumber
    
    if n == 1
      puedo = true
    end
    
    puedo
  end
  
  private
  def bringToLife
    @dead = false
  end
  
  def getCombatLevel
    bonus_j = @level
    
    @visibleTreasures.each{ |tesoro|  
      bonus_j = bonus_j + tesoro.bonus
    }
    
#    
#    @hiddenTreasures.each{  |tesoro|  
#      bonus_j = bonus_j + tesoro.bonus
#    }
    
    
    bonus_j
  end
  
  def incrementLevels(l)
    @level = @level + l
  end
  
  def decrementLevels(l)
    if @level - l < 0
      @level = 0
    else
      @level = @level - l
    end
  end
  
  def setPendingBadConsequence(b)
    @pendingBadConsequence = b
  end
  
  def applyPrize(m)
    nLevels = m.getLevelsGained
    incrementLevels(nLevels)
    
    nTreasures = m.getTreasuresGained
    
    if nTreasures > 0
      dealer = CardDealer.getInstance
      
      i=0
      while i < nTreasures
        treasure = dealer.nextTreasure
        @hiddenTreasures << treasure
        i = i+1
      end
    end
  end
  
  def applyBadConsequence(m)
    badConsequence = m.badConsequence
    
    nLevels = badConsequence.levels
    
    decrementLevels(nLevels)
    
    v = @visibleTreasures
    h = @hiddenTreasures
    pendingBad = badConsequence.adjustToFitTreasureList(v, h)
    
    setPendingBadConsequence(pendingBad)
    
  end
  
  def canMakeTreasureVisible(t)
    i = 0
    contador_una_mano = 0
    puedo = true
    dos_manos = false
    while i < @visibleTreasures.size && puedo
      if t.type == TreasureKind::ONEHAND
      j = 0
      while j < @visibleTreasures.size
        if @visibleTreasures.at(j).type == TreasureKind::ONEHAND
            contador_una_mano = contador_una_mano +1
        else
          if @visibleTreasures.at(j).type == TreasureKind::BOTHHANDS
            dos_manos = true
          end
        end

          j = j+1
        end
        if contador_una_mano >= 2 || dos_manos
          puedo = false
        end
      else
        if @visibleTreasures.at(i).type == t.type
          puedo = false
        else 
          if t.type == TreasureKind::BOTHHANDS
            j = 0
            while j < @visibleTreasures.size
              if @visibleTreasures.at(j).type == TreasureKind::ONEHAND
                puedo = false
              end
              j = j+1
            end
          end
        end
      end
      i = i +1
      end
    
    puedo
  end
  
  def howManyVisibleTreasures(tKind)
    number = 0
    
    @visibleTreasures.each |tesoro|  
      if tesoro.type == tKind
        number = number + 1
      end
      
    
  end
  
  def dieIfNoTreasures
    if @visibleTreasures.size == 0 && @hiddenTreasures.size == 0
      @dead = true
    end
  end
  
  public
  def isDead
    @dead
  end
  
  def combat(m)
    myLevel = getCombatLevel
    monsterLevel = getOponentLevel(m)
    
    if !@canISteal
      dice = Dice.getInstance
      number = dice.nextNumber
      
      if number < 3
        enemyLevel = @enemy.getCombat
        
        monsterLevel = monsterLevel + enemyLevel
      end
    end
      if myLevel > monsterLevel
        applyPrize(m)
        
        if @level >= @@MAXLEVEL
          cr = CombatResult::WINGAME
        else
          cr = CombatResult::WIN
        end
      else
        debo = shouldConvert
        
        applyBadConsequence(m)
        if debo
          cr = CombatResult::LOSEANDCONVERT
        end
        cr = CombatResult::LOSE
      end
    
    
    cr
  end
  
  def makeTreasureVisible(t)
    canI = canMakeTreasureVisible(t)
    
    if canI
      @visibleTreasures << t
      @hiddenTreasures.delete(t)
    end
  end
  
  def discardVisibleTreasure(t)
    @visibleTreasures.delete(t)
    
    if (@pendingBadConsequence != nil) && (!@pendingBadConsequence.isEmpty)
      @pendingBadConsequence.substractVisibleTreasure(t)
    end
    
    dieIfNoTreasures
  end
  
  def discardHiddenTreasure(t)
    @hiddenTreasures.delete(t)
       
    if (@pendingBadConsequence != nil) && (!@pendingBadConsequence.isEmpty)
      @pendingBadConsequence.substractHiddenTreasure(t)
    end
    
    dieIfNoTreasures
    
  end
  
  def validState
    valid = false
    if @pendingBadConsequence == nil
      if @hiddenTreasures.size <= 4
        valid = true
      else
        valid = false
      end
    else
      if @pendingBadConsequence.isEmpty && @hiddenTreasures.size <= 4
       valid = true
      end
    end
    
   
    
    valid
  end
  
  def initTreasures
    dealer = CardDealer.getInstance
    dice = Dice.getInstance
    
    bringToLife
    
    treasure = dealer.nextTreasure
    @hiddenTreasures << treasure
    
    number = dice.nextNumber
    
    if number > 1
      treasure = dealer.nextTreasure
      @hiddenTreasures << treasure
    end
    
    if number == 6
      treasure = dealer.nextTreasure
      @hiddenTreasures << treasure
    end
  end
  
  def stealTreasure
    canI = canISteal
    treasure = nil
    
    if canI
      canYou = @enemy.callCanYou
     
      if canYou
        treasure = @enemy.giveTreasure
        @hiddenTreasures << treasure
        haveStolen
      end
    end
    
    treasure
  end
  
  def setEnemy(enemy)
    @enemy = enemy
  end
  
  private
  def giveMeATreasure
    number = rand(@hiddenTreasures.size)
    
    @hiddenTreasures.at(number)
    
  end
  
  private
  def canYouGiveMeATreasure
    puedo = false
    
    if @visibleTreasures.size > 0 || @hiddenTreasures.size > 0
      puedo = true
    end
    
    puedo
  end
  
  def haveStolen
    @canISteal = false
  end
  
  public
  def discardAllTreasures
    i = 0
    
    visible = Array.new(@visibleTreasures)
    hidden = Array.new(@hiddenTreasures)
    
    while i<visible.size
      treasure = visible.at(i)
      discardVisibleTreasure(treasure)
      i = i+1
    end
    
    i = 0
    
    while i < hidden.size
      treasure = hidden.at(i)
      discardHiddenTreasure(treasure)
      i = i+1
    end
  end
  
  def Player.MAXLEVEL
    @@MAXLEVEL
  end
  
  def getHiddenTreasures
    @hiddenTreasures
  end
  
  def getVisibleTreasures
    @visibleTreasures
  end
  
  def callCanYou
    can = canYouGiveMeATreasure
    
    can
  end
  
  def giveTreasure
    t = giveMeATreasure
    
    t
  end
  
  def getCombat
    l = getCombatLevel
    
    l
  end
  
  def to_s
    "#{@name}   level = #{@level}"
  end
end
end