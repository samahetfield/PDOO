/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package napakalaki;

import java.util.ArrayList;

/**
 *
 * @author samaniego
 */
public class MixtoBadConsequence extends BadConsequence{
    private int nVisibleTreasures ;
    private int nHiddenTreasures ;
    private ArrayList<TreasureKind> specificVisibleTreasures;
    
    public MixtoBadConsequence(String text, int l, int nV, int nH, ArrayList<TreasureKind> tK){
        super(text, l);
        nVisibleTreasures = nV;
        nHiddenTreasures = nH;
        specificVisibleTreasures = tK;
    }
    
    protected int getNVisible(){
        return nVisibleTreasures;
    }
    
    protected int getNHidden(){
        return nHiddenTreasures;
    }
    
    protected ArrayList<TreasureKind> getSpecificVisible(){
        return specificVisibleTreasures;
    }
    
    public boolean isEmpty(){
        boolean vacio = false;
        
        if(nVisibleTreasures == 0 && nHiddenTreasures == 0 && specificVisibleTreasures.size() == 0){
            vacio = true;
        }
        
        return vacio;
    }
    
    public void substractVisibleTreasure(Treasure t){
        if(nVisibleTreasures > 0){
            nVisibleTreasures--;
        }
        for(int i=0; i<specificVisibleTreasures.size(); i++){
            if(specificVisibleTreasures.get(i) == t.getType()){
                specificVisibleTreasures.remove(i);
            }
        }
    }
    
    public void substractHiddenTreasure(Treasure t){
        if(nHiddenTreasures > 0){
            nHiddenTreasures--;
        }
    }
    
    public BadConsequence adjustToFitTreasureLists(ArrayList<Treasure> v, ArrayList<Treasure> h){
        boolean remove = false;
        MixtoBadConsequence bc;
        ArrayList<TreasureKind> visible = new ArrayList();
        ArrayList<TreasureKind> hidden = new ArrayList();
        ArrayList<Integer> pos_borrar_v = new ArrayList();
        
            for(int i=0; i<v.size(); i++){
                visible.add(v.get(i).getType());
            }

            for(int i=0; i<h.size(); i++){
                hidden.add(h.get(i).getType());
            }

            bc = new MixtoBadConsequence("", 0, this.nVisibleTreasures, this.nHiddenTreasures, this.specificVisibleTreasures);

            if(v.size() > this.nVisibleTreasures){
                bc.nVisibleTreasures = 0;
            }
            else{
                bc.nVisibleTreasures = v.size();
            }

            if(h.size() > this.nHiddenTreasures){
                bc.nHiddenTreasures = 0;
            }
            else{
                bc.nHiddenTreasures = h.size();
            }
            
            for(int i=0; i<v.size(); i++){
                for(int j=0; j< specificVisibleTreasures.size() && !remove; j++){
                    if(specificVisibleTreasures.get(j) == v.get(i).getType()){
                        pos_borrar_v.add(i);
                    }  
                }
            }
            
            boolean borrar = true;
            
            for(int i=0; i<v.size(); i++){
                borrar = true;
                for(int j=0; j<pos_borrar_v.size(); j++){
                    if(i == pos_borrar_v.get(j)){
                        borrar = false;
                    }

                }
                if(borrar){
                    bc.specificVisibleTreasures.remove(v.get(i).getType());
                }
            }
        return bc;
    }
    
    public String toString(){
        return super.toString() 
             + "\nnVisibleTreasures = " + Integer.toString(nVisibleTreasures) 
             + "\nnHiddenTreasures = " + Integer.toString(nHiddenTreasures) + "\n";
    }
}

