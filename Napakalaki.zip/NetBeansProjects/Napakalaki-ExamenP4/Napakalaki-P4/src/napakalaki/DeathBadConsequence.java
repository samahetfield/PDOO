/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package napakalaki;

import java.util.ArrayList;

/**
 *
 * @author Sergio SM
 */
public class DeathBadConsequence extends NumericBadConsequence{
    
    private boolean death;
    
    public DeathBadConsequence(String t, int l, int nV, int nH, boolean d){
        super(t,l,nV,nH);
        death = d;
    }
    
    public boolean isEmpty(){
        boolean vacio = false;
        if(super.getNVisible() == BadConsequence.MAXTREASURES && super.getLevel() == Player.MAXLEVEL){
            vacio = true;
        }
        
        return vacio;
    }
    
    
    public void substractVisibleTreasure(Treasure t){
        super.substractVisibleTreasure(t);
    }
    
    public void substractHiddenTreasure(Treasure t){
        super.substractHiddenTreasure(t);
    }
    
    public BadConsequence adjustToFitTreasureLists(ArrayList<Treasure> v, ArrayList<Treasure> h){
      return super.adjustToFitTreasureLists(v, h);
    }
    
    public String toString(){
        return super.toString()
             + "\nDeath = " + Boolean.toString(death) ;
    }
    
}
