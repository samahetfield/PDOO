/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package napakalaki;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

/**
 *
 * @author sergio
 */
public class CardDealer {
    private static final CardDealer instance = new CardDealer();
    private ArrayList<Monster> unusedMonsters = null;
    private ArrayList<Monster> usedMonsters = null;
    private ArrayList<Treasure> unusedTreasures = null;
    private ArrayList<Treasure> usedTreasures = null;
    private ArrayList<Cultist> unusedCultist = null;
    
    private CardDealer(){
        unusedMonsters = new ArrayList();
        usedMonsters = new ArrayList();
        unusedTreasures = new ArrayList();
        usedTreasures = new ArrayList();
        unusedCultist = new ArrayList();
    }
    
    private void initTreasureCardDeck(){
        //Tesoro 1
        unusedTreasures.add(new Treasure("¡Si mi amo!", 4, TreasureKind.HELMET));
        
        //Tesoro 2
        unusedTreasures.add(new Treasure("Botas de investigacion", 3, TreasureKind.SHOES));
        
        //Tesoro 3
        unusedTreasures.add(new Treasure("Capucha Cthulhu", 3, TreasureKind.HELMET));
        
        //Tesoro 4
        unusedTreasures.add(new Treasure("A prueba de babas", 2, TreasureKind.ARMOR));
        
        //Tesoro 5
        unusedTreasures.add(new Treasure("Botas de lluvia ácida", 1, TreasureKind.BOTHHANDS));
        
        //Tesoro 6
        unusedTreasures.add(new Treasure("Casco minero", 2, TreasureKind.HELMET));
        
        //Tesoro 7
        unusedTreasures.add(new Treasure("Ametralladora ACME", 4, TreasureKind.BOTHHANDS));
        
        //Tesoro 8
        unusedTreasures.add(new Treasure("Camiseta de la ETSIIT", 1, TreasureKind.ARMOR));
        
        //Tesoro 9
        unusedTreasures.add(new Treasure("Clavo de rail ferroviario", 3, TreasureKind.ONEHAND));
        
        //Tesoro 10
        unusedTreasures.add(new Treasure("Cuchillo de sushi arcano", 2, TreasureKind.ONEHAND));
        
        //Tesoro 11
        unusedTreasures.add(new Treasure("Fez alopodo", 3, TreasureKind.HELMET));
        
        //Tesoro 12
        unusedTreasures.add(new Treasure("Hacha prehistorica", 2, TreasureKind.ONEHAND));
        
        //Tesoro 13
        unusedTreasures.add(new Treasure("El aparato del Pr. Tesla", 4, TreasureKind.ARMOR));
        
        //Tesoro 14
        unusedTreasures.add(new Treasure("Gaita", 4, TreasureKind.BOTHHANDS));
        
        //Tesoro 15
        unusedTreasures.add(new Treasure("Insecticida", 2, TreasureKind.ONEHAND));
        
        //Tesoro 16
        unusedTreasures.add(new Treasure("Escopeta de 3 cañones", 4, TreasureKind.BOTHHANDS));
        
        //Tesoro 17
        unusedTreasures.add(new Treasure("Garabato mistico", 2, TreasureKind.ONEHAND));
        
        //Tesoro 18
        unusedTreasures.add(new Treasure("La rebeca metalica", 2, TreasureKind.ARMOR));
        
        //Tesoro 19
        unusedTreasures.add(new Treasure("Lanzallamas", 4, TreasureKind.BOTHHANDS));
        
        //Tesoro 20
        unusedTreasures.add(new Treasure("Necro-comicon", 1, TreasureKind.ONEHAND));
        
        //Tesoro 21
        unusedTreasures.add(new Treasure("Necronomicon", 5, TreasureKind.BOTHHANDS));
        
        //Tesoro 22
        unusedTreasures.add(new Treasure("Linterna a 2 manos", 3, TreasureKind.BOTHHANDS));
        
        //Tesoro 23
        unusedTreasures.add(new Treasure("Necro-gnomicon", 2, TreasureKind.ONEHAND));
        
        //Tesoro 24
        unusedTreasures.add(new Treasure("Necrotelecom", 2, TreasureKind.HELMET));
        
        //Tesoro 25
        unusedTreasures.add(new Treasure("Mazo de los antiguos", 3, TreasureKind.ONEHAND));
        
        //Tesoro 26
        unusedTreasures.add(new Treasure("Necro-playboycon", 3, TreasureKind.ONEHAND));
        
        //Tesoro 27
        unusedTreasures.add(new Treasure("Porra preternatural", 2, TreasureKind.ONEHAND));
        
        //Tesoro 28
        unusedTreasures.add(new Treasure("Shogulador", 1, TreasureKind.BOTHHANDS));
        
        //Tesoro 29
        unusedTreasures.add(new Treasure("Varita de atizamiento", 3, TreasureKind.ONEHAND));
        
        //Tesoro 30
        unusedTreasures.add(new Treasure("Tentaculo de pega", 2, TreasureKind.HELMET));
        
        //Tesoro 31
        unusedTreasures.add(new Treasure("Zapato deja-amigos", 1, TreasureKind.SHOES));
    }
    
    private void initMonsterCardDeck(){
    //Monstruo 1
        BadConsequence badConsequence = new SpecificBadConsequence("Pierdes tu armadura visible y otra oculta", 0, new ArrayList(Arrays.asList(TreasureKind.ARMOR)),new ArrayList(Arrays.asList(TreasureKind.ARMOR)));
        Prize prize = new Prize(2,1);
        unusedMonsters.add(new Monster("3 Byakhees de Bonanza", 8, badConsequence, prize,0));
        
        //Monstruo 2
        badConsequence = new SpecificBadConsequence("Embobados con el lindo primigenio te descartas de tu casco visible", 0, new ArrayList(Arrays.asList(TreasureKind.HELMET)), new ArrayList());
        prize = new Prize(1,1);
        unusedMonsters.add(new Monster("Tenochtitlan", 2, badConsequence, prize,0));
        
        //Monstruo 3
        badConsequence = new SpecificBadConsequence("El primordial bostezo contagioso. Pierdes el calzado visible", 0, new ArrayList(Arrays.asList(TreasureKind.SHOES)),new ArrayList() );
        prize = new Prize(1,1);
        unusedMonsters.add(new Monster("El sopor de Dunwich", 2, badConsequence, prize,0));
        
        //Monstruo 4
        badConsequence = new SpecificBadConsequence("Te atrapan para llevarte de fiesta y te dejan caer en mitad del vuelo. Descarta 1 mano visible y 1 mano oculta", 0, new ArrayList(Arrays.asList(TreasureKind.ONEHAND)), new ArrayList(Arrays.asList(TreasureKind.ONEHAND)));
        prize = new Prize(4,1);
        unusedMonsters.add(new Monster("Demonios de Magaluf", 2, badConsequence, prize,0));
        
        //Monstruo 5
        badConsequence = new NumericBadConsequence("Pierdes todos tus tesoros visibles", 0, BadConsequence.MAXTREASURES, 0);
        prize = new Prize(3,1);
        unusedMonsters.add(new Monster("El gorrón en el umbral", 13, badConsequence, prize,0));
        
        //Monstruo 6
        badConsequence = new SpecificBadConsequence("Pierdes la armadura visible", 0, new ArrayList(Arrays.asList(TreasureKind.ARMOR)), new ArrayList());
        prize = new Prize(2,1);
        unusedMonsters.add(new Monster("H.P Munchcraft", 6, badConsequence, prize,0));
        
        //Monstruo 7
        badConsequence = new SpecificBadConsequence("Sientes bichos bajo la ropa. Descarta tu armadura visible", 0, new ArrayList(Arrays.asList(TreasureKind.ARMOR)), new ArrayList());
        prize = new Prize(1,1);
        unusedMonsters.add(new Monster("Necrófago", 13, badConsequence, prize,0));
        
        //Monstruo 8
        badConsequence = new NumericBadConsequence("Pierdes 5 niveles y 3 tesoros visibles", 5, 3, 0);
        prize = new Prize(3,2);
        unusedMonsters.add(new Monster("El rey de rosado", 11, badConsequence, prize,0));
        
        //Monstruo 9
        badConsequence = new NumericBadConsequence("Toses los pulmones y pierdes 2 niveles", 2, 0, 0);
        prize = new Prize(1,1);
        unusedMonsters.add(new Monster("Flecher", 2, badConsequence, prize,0));
        
        //Monstruo 10
        badConsequence = new DeathBadConsequence("Estos monstruos resultan bastante superficiales y te aburren mortalmente. Estas muerto", Player.MAXLEVEL, BadConsequence.MAXTREASURES, BadConsequence.MAXTREASURES, true);
        prize = new Prize(2,1);
        unusedMonsters.add(new Monster("Los hondos", 8, badConsequence, prize,0));
        
        //Monstruo 11
        badConsequence = new NumericBadConsequence("Pierdes 2 niveles y 2 tesoros ocultos", 2, 0, 2);
        prize = new Prize(2,1);
        unusedMonsters.add(new Monster("Semillas Cthulhu", 4, badConsequence, prize,0));
        
        //Monstruo 12
        badConsequence = new SpecificBadConsequence("Te intentas escaquear. Pierdes 1 mano visible", 0, new ArrayList(Arrays.asList(TreasureKind.ONEHAND)), new ArrayList());
        prize = new Prize(2,1);
        unusedMonsters.add(new Monster("Dameargo", 1, badConsequence, prize,0));
        
        //Monstruo 13
        badConsequence = new NumericBadConsequence("Da mucho asquito. Pierdes 3 niveles", 3, 0, 0);
        prize = new Prize(2,1);
        unusedMonsters.add(new Monster("Pollipólipo volante", 3, badConsequence, prize,0));
        
        //Monstruo 14
        badConsequence = new DeathBadConsequence("No le hace gracia que pronuncien mal su nombre. Estas muerto",Player.MAXLEVEL, BadConsequence.MAXTREASURES, BadConsequence.MAXTREASURES, true);
        prize = new Prize(3,1);
        unusedMonsters.add(new Monster("Yskhtihyssg-Goth", 14, badConsequence, prize,0));
        
        //Monstruo 15
        badConsequence = new DeathBadConsequence("La familia te atrapa. Estas muerto", Player.MAXLEVEL, BadConsequence.MAXTREASURES, BadConsequence.MAXTREASURES, true);
        prize = new Prize(3,1);
        unusedMonsters.add(new Monster("Familia feliz", 1, badConsequence, prize,0));
        
        //Monstruo 16
        badConsequence = new SpecificBadConsequence("La quinta directiva te obliga a perder 2 niveles y un tesoro 2 manos visibles", 2, new ArrayList(Arrays.asList(TreasureKind.BOTHHANDS)), new ArrayList());
        prize = new Prize(2,1);
        unusedMonsters.add(new Monster("Roboggoth", 13, badConsequence, prize,0));
        
        //Monstruo 17
        badConsequence = new SpecificBadConsequence("Te asusta en la noche. Pierdes un casco visible", 0, new ArrayList(Arrays.asList(TreasureKind.HELMET)), new ArrayList());
        prize = new Prize(1,1);
        unusedMonsters.add(new Monster("El espía sordo", 5, badConsequence, prize,0));
        
        //Monstruo 18
        badConsequence = new NumericBadConsequence("Menudo susto te llevas. Pierdes 2 niveles y 5 tesoros visibles", 2, 5, 0);
        prize = new Prize(2,1);
        unusedMonsters.add(new Monster("Tongue", 19, badConsequence, prize,0));
        
        //Monstruo 19
        badConsequence = new SpecificBadConsequence("Te faltan manos para tanta cabeza. Pierdes 3 nivles y tus tesoros visibles de las manos", 3, new ArrayList(Arrays.asList(TreasureKind.ONEHAND, TreasureKind.ONEHAND, TreasureKind.BOTHHANDS)), new ArrayList());
        prize = new Prize(2,1);
        unusedMonsters.add(new Monster("Bicéfalo", 21, badConsequence, prize,0));
        
        //Monstruos sectarios
        
        badConsequence = new SpecificBadConsequence("Pierdes 1 mano visible", 0, new ArrayList(Arrays.asList(TreasureKind.ONEHAND)), new ArrayList());
        prize = new Prize(3,1);
        unusedMonsters.add(new Monster("El mal indecible impronunciable", 10, badConsequence, prize,-2));
        
        badConsequence = new NumericBadConsequence("Pierdes tus tesoros visibles. Jajaja", 0, BadConsequence.MAXTREASURES, 0);
        prize = new Prize(2,1);
        unusedMonsters.add(new Monster("Testigos oculares", 6, badConsequence, prize,+2));
        
        badConsequence = new DeathBadConsequence("Hoy no es tu dia de suerte. Mueres",Player.MAXLEVEL, BadConsequence.MAXTREASURES, BadConsequence.MAXTREASURES, true);
        prize = new Prize(2,5);
        unusedMonsters.add(new Monster("El gran Ctulhu", 20, badConsequence, prize,+4));
        
        badConsequence = new NumericBadConsequence("Tu gobierno te recorta 2 niveles.", 2,0, 0);
        prize = new Prize(2,1);
        unusedMonsters.add(new Monster("Serpiente Político", 8, badConsequence, prize,-2));
        
        badConsequence = new SpecificBadConsequence("Pierdes tu casco y tu armadura visible.Pierdes tus manos ocultas", 0, new ArrayList(Arrays.asList(TreasureKind.HELMET, TreasureKind.ARMOR)), new ArrayList(Arrays.asList(TreasureKind.ONEHAND, TreasureKind.ONEHAND, TreasureKind.BOTHHANDS)));
        prize = new Prize(1,1);
        unusedMonsters.add(new Monster("Felpuggoth", 2, badConsequence, prize,+5));
        
        badConsequence = new NumericBadConsequence("Pierdes 2 nivles", 2, 0, 0);
        prize = new Prize(4,2);
        unusedMonsters.add(new Monster("Shoggoth", 16, badConsequence, prize,-4));
        
        badConsequence = new NumericBadConsequence("Pintalabios negro. Pierdes 2 niveles.", 2, 0, 0);
        prize = new Prize(1,1);
        unusedMonsters.add(new Monster("Lolitagooth", 2, badConsequence, prize,+3));
    }
    
    private void shuffleTreasures(){
        Collections.shuffle(unusedTreasures);
        
    }
    
    private void shuffleMonsters(){
        Collections.shuffle(unusedMonsters);
        
    }
    
    public static CardDealer getInstance(){
        return instance;
    }
    
    public Treasure nextTreasure(){
        if(unusedTreasures.size() == 0){
            unusedTreasures = usedTreasures;
            usedTreasures.clear();
            this.shuffleTreasures();
        }
        
        Treasure tesoro = unusedTreasures.get(0);
        usedTreasures.add(tesoro);
        unusedTreasures.remove(tesoro);
        
        return tesoro;
    }
    
    public Monster nextMonster(){
        if(unusedMonsters.size() == 0){
            unusedMonsters = usedMonsters;
            usedMonsters.clear();
            this.shuffleMonsters();
        }
        
        Monster m = unusedMonsters.get(0);
        usedMonsters.add(m);
        unusedMonsters.remove(m);
        
        return m;
    }
    
    public void giveTreasureBack(Treasure t){
        usedTreasures.add(t);
        
        unusedTreasures.remove(t);
    }
    
    public void giveMonsterBack(Monster t){
        usedMonsters.add(t);
        
        unusedMonsters.remove(t);
    }
    
    private void shuffleCultist(){
        Collections.shuffle(unusedCultist);
        
    }
    
    private void initCultistCardDeck(){
        unusedCultist.add(new Cultist("Sectario", +1));
        unusedCultist.add(new Cultist("Sectario", +2));
        unusedCultist.add(new Cultist("Sectario", +1));
        unusedCultist.add(new Cultist("Sectario", +2));
        unusedCultist.add(new Cultist("Sectario", +1));
        unusedCultist.add(new Cultist("Sectario", +1));
    }
    
    public Cultist nextCultist(){
        Cultist c = unusedCultist.get(0);
        
        unusedCultist.remove(c);
        
        return c;
    }
    
    
    public void initCards(){
        initTreasureCardDeck();
        initMonsterCardDeck();
        initCultistCardDeck();
        
        this.shuffleCultist();
        this.shuffleMonsters();
        this.shuffleTreasures();
    }
}
