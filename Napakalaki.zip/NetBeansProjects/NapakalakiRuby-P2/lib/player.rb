# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative 'treasure.rb'
require_relative 'bad_consequence.rb'
require_relative 'card_dealer.rb'
require_relative 'dice.rb'
require_relative 'combat_result.rb'

class Player
  attr_reader :name, :visibleTreasures, :hiddenTreasures, :level, :canISteal
  
  @@MAXLEVEL = 10
  def initialize(name)
    @name = name
    @level = 0
    @dead = false
    @canISteal = false 
    @enemy = Player.new("")
    @visibleTreasures = Array.new
    @hiddenTreasures = Array.new
    @pendingBadConsequence = BadConsequence.newDeath("")
  end
  
  private
  def bringToLife
    @dead = false
  end
  
  def getCombatLevel
    bonus_j = @level
    
    @visibleTreasures.each  |tesoro|  
      bonus_j = bonus_j + tesoro.bonus
    
    
    @hiddenTreasures.each  |tesoro|  
      bonus_j = bonus_j + tesoro.bonus
    
    
    bonus_j
  end
  
  def incrementLevels(l)
    @level = @level + l
  end
  
  def decrementLevels(l)
    if @level - l < 0
      @level = 0
    else
      @level = @level - l
    end
  end
  
  def setPendingBadConsequence(b)
    @pendingBadConsequence = b
  end
  
  def applyPrize(m)
    
  end
  
  def applyBadConsequence(m)
    
  end
  
  def canMakeTreasureVisible(t)
    
  end
  
  def howManyVisibleTreasures(tKind)
    number = 0
    
    @visibleTreasures.each |tesoro|  
      if tesoro.type == tKind
        number = number + 1
      end
      
    
  end
  
  def dieIfNoTreasures
    if @visibleTreasures.size == 0 && @hiddenTreasures.size == 0
      @dead = true
    end
  end
  
  public
  def isDead
    @dead
  end
  
  def combat(m)
    
  end
  
  def makeTreasureVisible(t)
    
  end
  
  def discardVisibleTreasure(t)
    
  end
  
  def discardHiddenTreasure(t)
    
  end
  
  def validState
    valid = falss
    if @pendingBadConsequence.isEmpty && @hiddenTreasures.size <= 4
      valid = true
    end
    
    valid
  end
  
  def initTreasures
    
  end
  
  def stealTreasure
    
  end
  
  def setEnemy(enemy)
    @enemy = enemy
  end
  
  private
  def giveMeATreasure
    
  end
  
  public
  
  private
  def canYouGiveMeATreasure
    puedo = false
    
    if @visibleTreasures.size > 0 || @hiddenTresaures.size > 0
      puedo = true
    end
    
    puedo
  end
  
  def haveStolen
    @canISteal = false
  end
  
  public
  def discardAllTreasures
    
  end
end
