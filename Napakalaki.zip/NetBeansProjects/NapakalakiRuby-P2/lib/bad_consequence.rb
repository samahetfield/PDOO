# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative 'treasure_kind.rb'

class BadConsequence
  attr_reader :text, :levels, :nVisibleTreasures, :nHiddenTreasures, :death, :specificHiddenTreasures, :specificVisibleTreasures;
  private_class_method :new
  
  @@MAXTREASURES = 10
  def initialize(aText, some_levels, some_visible_treasures, some_hidden_treasures, some_specific_visible_treasures, some_specific_hidden_treasures, death)
    @text = aText
    @levels = some_levels
    @nVisibleTreasures = some_visible_treasures
    @nHiddenTreasures = some_hidden_treasures
    @death = death
    @specificHiddenTreasures = some_specific_hidden_treasures
    @specificVisibleTreasures = some_specific_visible_treasures
  end
  
  def BadConsequence.newLevelNumberOfTreasures(aText, some_levels, some_visible_treasures, some_hidden_treasures)
    new(aText, some_levels, some_visible_treasures, some_hidden_treasures, [], [], false)
  end
  
  def BadConsequence.newLevelSpecificTreasures(aText, some_levels, some_specific_visible_treasures, some_specific_hidden_treasures)
    new(aText, some_levels, -1, -1, some_specific_visible_treasures, some_specific_hidden_treasures, false)
  end
  
  def BadConsequence.newDeath(aText)
    new(aText, 0, -1, -1, [], [], true)
  end
  
  def isEmpty
    vacio = false
    if @nVisibleTreasures == 0 && @nHiddenTreasures == 0 && @specificVisibleTreasures.size == 0
      vacio = true
    else
      if @nVisibleTreasures == -1 && @specificVisibleTreasures.size == 0 && @specificHiddenTreasures.size == 0
        vacio = true
      end
    end
    
    vacio
  end
  
  def substractVisibleTreasure(t)
    
  end
  
  def substractHiddenTreasures(t)
    
  end
  
  def adjustToFitTreasureList(v,h)
    
  end
  
  def to_s
    "Name: #{@text} \n Levels: #{@levels} \n nVisibleTreasures: #{@nVisibleTreasures} \n nHiddenTreasures: #{@nHiddenTreasures} \n Death: #{@death} \n SpecificVisibleTreasures: #{@specificVisibleTreasures} \n SpecificHiddenTreasures: #{@specificHiddenTreasures}"
  end 
end
