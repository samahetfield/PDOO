# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

require_relative 'player.rb'
require_relative 'combat_result.rb'
require_relative 'monster.rb'
require_relative 'card_dealer.rb'
require 'singleton'

class Napakalaki
  include Singleton
  @@instance = null
  
  private
  def initialize
    @currentPlayer = Player.new("")
    @players = Array.new
    @dealer = CardDealer.getInstance
    @currentMonster = Monster.new("", 0, nil, nil)
  end
  
  def initPlayers(names)
    
  end
  
  def nextPlayer
    
  end
  
  def nextTurnAllowed
    
  end
  
  def setEnemies
    
  end
  
  public
  def Napakalaki.getInstance
    Napakalaki.instance
  end
  
  def developCombat
    
  end
  
  def discardVisibleTreasures(t)
    
  end
  
  def discardHiddenTreasures(t)
    
  end
  
  def makeTreasuresVisible(t)
    
  end
  
  def initGame(players)
    
  end
  
  def getCurrentPlayer
    @currentPlayer
  end
  
  def getCurrentMonster
    @currentMonster
  end
  
  def nextTurn
    
  end
  
  def endOfGame(result)
    
  end
  
end
