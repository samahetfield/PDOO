/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package napakalaki;
import GUI.NapakalakiView;
import GUI.Dice;
import GUI.PlayersNamesCapture;

import Test.GameTester;
import java.util.ArrayList;

/**
 *
 * @author Sergio SM
 */
public class main {
    public static void main(String[] args) {
      ArrayList<String> names;  
      
      Napakalaki game = Napakalaki.getInstance();
      NapakalakiView napakalakiView = new NapakalakiView();
      
      PlayersNamesCapture namesCapture = new PlayersNamesCapture(napakalakiView, true);

      Dice.createInstance(napakalakiView);             
      names = namesCapture.getNames();
      game.initGame(names);
      napakalakiView.setNapakalaki(game);
      napakalakiView.setVisible (true);


    }
}
