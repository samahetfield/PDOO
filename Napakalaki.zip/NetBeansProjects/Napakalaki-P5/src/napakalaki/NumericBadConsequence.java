/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package napakalaki;

import java.util.ArrayList;

/**
 *
 * @author Sergio SM
 */
public class NumericBadConsequence extends BadConsequence{
    
    private int nVisibleTreasures ;
    private int nHiddenTreasures ;
    
    public NumericBadConsequence(String text, int l, int nV, int nH){
        super(text, l);
        nVisibleTreasures = nV;
        nHiddenTreasures = nH;
    }
    
    public ArrayList getVisibleTreasures(){
        ArrayList<Treasure> v = new ArrayList();

        return v;
    }
    
    public ArrayList getHiddenTreasures(){
        ArrayList<Treasure> h = new ArrayList();
  
        return h;
    }
    
    public int getnVisibleTreasures(){
        return nVisibleTreasures;
    }
    
    public int getnHiddenTreasures(){
        return nHiddenTreasures;
    }
    
    public boolean isEmpty(){
        boolean vacio = false;
        
        if(nVisibleTreasures == 0 && nHiddenTreasures == 0){
            vacio = true;
        }
        
        return vacio;
    }
    
    public void substractVisibleTreasure(Treasure t){
        if(nVisibleTreasures > 0){
            nVisibleTreasures--;
        }
    }
    
    public void substractHiddenTreasure(Treasure t){
        if(nHiddenTreasures > 0){
            nHiddenTreasures--;
        }
    }
    
    public BadConsequence adjustToFitTreasureLists(ArrayList<Treasure> v, ArrayList<Treasure> h){
       boolean remove = false;
        NumericBadConsequence bc;
        ArrayList<TreasureKind> visible = new ArrayList();
        ArrayList<TreasureKind> hidden = new ArrayList();
        
            for(int i=0; i<v.size(); i++){
                visible.add(v.get(i).getType());
            }

            for(int i=0; i<h.size(); i++){
                hidden.add(h.get(i).getType());
            }

            bc = new NumericBadConsequence("", 0, this.nVisibleTreasures, this.nHiddenTreasures);

            if(v.size() > this.nVisibleTreasures){
                bc.nVisibleTreasures = 0;
            }
            else{
                bc.nVisibleTreasures = v.size();
            }

            if(h.size() > this.nHiddenTreasures){
                bc.nHiddenTreasures = 0;
            }
            else{
                bc.nHiddenTreasures = h.size();
            }
        return bc;
    }
    
        public String toString(){
        return super.toString() 
             + "\nnVisibleTreasures = " + Integer.toString(nVisibleTreasures) 
             + "\nnHiddenTreasures = " + Integer.toString(nHiddenTreasures) + "\n";
    }
}
