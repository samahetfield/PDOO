/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package napakalaki;

import java.util.ArrayList;

/**
 *
 * @author Sergio SM
 */
public class CultistPlayer extends Player {
    private static int totalCultistPlayer = 0;
    private Cultist myCultistCard;
    
    public CultistPlayer(Player p, Cultist c){
        super(p);
        myCultistCard = c;
        totalCultistPlayer++;
    }
    
    public int getCombatLevel(){
        int cl =(int) (super.getCombatLevel() + (super.getCombatLevel()*0.2));
        int c = (myCultistCard.getGainedLevels()*totalCultistPlayer);
        
        return cl+c;
    }
    
    protected int getOponentLevel(Monster m){
        return m.getCombatLevelAgainstCultistPlayer();
    }
    
    protected boolean shouldConvert(){
        return false;
    }
    
    private Treasure giveMeATreasure(){
        ArrayList<Treasure> t = this.getVisibleTreasures();
        
        int number = (int) (Math.random()*t.size());        
        return t.get(number);
    }
    
    private boolean canYouGiveMeATreasure(){
        boolean have = false;
        
        if(enemy.getVisibleTreasures().size() > 0){
            have = true;
        }
        
        return have;
    }
    
    public static int getTotalCultistPlayer(){
        return totalCultistPlayer;
    }
}
