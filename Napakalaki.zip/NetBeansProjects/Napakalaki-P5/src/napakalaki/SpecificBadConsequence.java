/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package napakalaki;

import java.util.ArrayList;

/**
 *
 * @author Sergio SM
 */
public class SpecificBadConsequence extends BadConsequence{
   
    private ArrayList<TreasureKind> specificHiddenTreasures;
    private ArrayList<TreasureKind> specificVisibleTreasures;
    
    public SpecificBadConsequence(String n, int l, ArrayList<TreasureKind> sV, ArrayList<TreasureKind> sH){
        super(n,l);
        specificVisibleTreasures = sV;
        specificHiddenTreasures = sH;
    }
    
    public ArrayList getVisibleTreasures(){
        ArrayList<Treasure> v = new ArrayList();
        for(int i=0; i<specificVisibleTreasures.size(); i++){
            Treasure t = new Treasure("",0,specificVisibleTreasures.get(i));
            v.add(t);
        }
        
        return v;
        
    }
    
    public ArrayList getHiddenTreasures(){
        ArrayList<Treasure> v = new ArrayList();
        for(int i=0; i<specificHiddenTreasures.size(); i++){
            Treasure t = new Treasure("",0,specificHiddenTreasures.get(i));
            v.add(t);
        }
        
        return v;   
    }
    
    public int getnVisibleTreasures(){
        return 0;
    }
    
    public int getnHiddenTreasures(){
        return 0;
    }
    
    public boolean isEmpty(){
        boolean vacio = false;
        
        if(specificVisibleTreasures.size() == 0 && specificHiddenTreasures.size() == 0){
            vacio = true;
        }
        
        return vacio;
    } 
    
    public void substractVisibleTreasure(Treasure t){
        specificVisibleTreasures.remove(t.getType());
        
    }
    
    public void substractHiddenTreasure(Treasure t){   
        specificHiddenTreasures.remove(t.getType());

    }
    
    public SpecificBadConsequence adjustToFitTreasureLists(ArrayList<Treasure> v, ArrayList<Treasure> h){
        boolean remove = false;
        SpecificBadConsequence bc;
        ArrayList<TreasureKind> visible = new ArrayList();
        ArrayList<TreasureKind> hidden = new ArrayList();
        ArrayList<Integer> pos_borrar_v = new ArrayList();
        ArrayList<Integer> pos_borrar_h = new ArrayList();
          
            for(int i=0; i<v.size(); i++){
                visible.add(v.get(i).getType());
            }

            for(int i=0; i<h.size(); i++){
                hidden.add(h.get(i).getType());
            }

            bc = new SpecificBadConsequence("", 0, visible, hidden);
            for(int i=0; i<v.size(); i++){
                for(int j=0; j< specificVisibleTreasures.size() && !remove; j++){
                    if(specificVisibleTreasures.get(j) == v.get(i).getType()){
                        pos_borrar_v.add(i);
                    }  
                }
            }

            for(int i=0; i<h.size(); i++){
                for(int j=0; j< specificHiddenTreasures.size() && !remove; j++){
                    if(specificHiddenTreasures.get(j) == h.get(i).getType()){
                        pos_borrar_h.add(i);
                    }  
                }
            }
            
            boolean borrar = true;
            
            for(int i=0; i<v.size(); i++){
                borrar = true;
                for(int j=0; j<pos_borrar_v.size(); j++){
                    if(i == pos_borrar_v.get(j)){
                        borrar = false;
                    }

                }
                if(borrar){
                    bc.specificVisibleTreasures.remove(v.get(i).getType());
                }
            }
            
            borrar = true;
            for(int i=0; i<h.size(); i++){
                borrar = true;
                for(int j=0; j<pos_borrar_h.size(); j++){
                    if(i == pos_borrar_h.get(j)){
                        borrar = false;
                    }

                }
                if(borrar){
                    bc.specificHiddenTreasures.remove(h.get(i).getType());
                }
            }
            
        
    
        return bc;
    }
    
        public String toString(){
        return super.toString()
             + "\nSpecificVisibleTreasures = " + specificVisibleTreasures
             + "\nSpecificHiddenTreasures = " + specificHiddenTreasures+ "\n";
    }
    
}
