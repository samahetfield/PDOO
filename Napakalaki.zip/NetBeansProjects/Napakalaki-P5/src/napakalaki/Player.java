/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package napakalaki;

import java.util.ArrayList;
import GUI.Dice;

/**
 *
 * @author sergio
 */
public class Player {
    static final int MAXLEVEL = 10;
    private String name;
    private int level;
    private boolean dead;
    private boolean canISteal;
    protected Player enemy = null;
    private ArrayList<Treasure> hiddenTreasures = new ArrayList();
    private ArrayList<Treasure> visibleTreasures = new ArrayList();
    private BadConsequence pendingBadConsequence = null;
    
    public Player(String n){
        name = n;
        level = 0;
        dead = true;
        canISteal = true;
        pendingBadConsequence = null;
    }
    
    public Player(Player p){
        name = p.getName();
        level = p.getLevels();
        dead = p.getDead();
        canISteal = p.canISteal();
        hiddenTreasures = p.getHiddenTreasures();
        visibleTreasures = p.getVisibleTreasures();
        pendingBadConsequence = p.getPendingBadConsequence();
        enemy = p.getEnemy();
    }
    
    protected int getOponentLevel(Monster m){
        return m.getCombatLevel();
    }
    
    protected boolean shouldConvert(){
        Dice dice = Dice.getInstance();
        boolean puedo = false;
        
        int number = dice.nextNumber();
        
        if(number == 1){
            puedo = true;
        }
        
        return puedo;
    }
    
    public Player getEnemy(){
        return enemy;
    }
    public String getName(){
        return name;
    }
    
    public boolean getDead(){
        return dead;
    }
    
    public BadConsequence getPendingBadConsequence(){
        return pendingBadConsequence;
    }
    
    private void bringToLife(){
        dead = false;
    }
    
    public int getCombatLevel(){
        int bonus_j = level;
        for(int i=0; i<visibleTreasures.size(); i++){
            bonus_j += visibleTreasures.get(i).getBonus();
        }
       /* 
        for(int i=0; i<hiddenTreasures.size(); i++){
            bonus_j += hiddenTreasures.get(i).getBonus();
        }
        */
        return bonus_j;
    }
    
    private void incrementLevels(int l){
        level += l;
    }
    
    private void decrementLevels(int l){
        if(level-l >= 0)
            level -= l;
        else
            level = 0;
    }
    
    private void setPendingBadConsequence(BadConsequence b){
        pendingBadConsequence = b;
    }
    
    private void applyPrize(Monster m){
        int nLevels = m.getLevelsGained();
        
        this.incrementLevels(nLevels);
        
        int nTreasures = m.getTreasuresGained();
        
        if(nTreasures > 0){
            CardDealer dealer = CardDealer.getInstance();
            
            for(int i=0; i<nTreasures; i++){
                Treasure treasure = dealer.nextTreasure();
                hiddenTreasures.add(treasure);
            }
        }
    }
    
    private void applyBadConsequence(Monster m){
        BadConsequence badConsequence = m.getBadConsequence();
        
        int nLevels = badConsequence.getLevel();
        
        decrementLevels(nLevels);
        
        ArrayList<Treasure> v = visibleTreasures;
        ArrayList<Treasure> h = hiddenTreasures;
        BadConsequence pendingBad = badConsequence.adjustToFitTreasureLists(v, h);
        
        setPendingBadConsequence(pendingBad);
    }   
    
    private boolean canMakeTreasureVisible(Treasure t){
        boolean puedo = true;
        boolean dos_manos = false;
        int contador_una_mano = 0;
        
        int tam_visible = visibleTreasures.size();
        
        for(int i=0; i<tam_visible; i++){
            if(t.getType() == TreasureKind.ONEHAND){
                for(int j=0; j<tam_visible; j++){
                    if(visibleTreasures.get(j).getType() == TreasureKind.ONEHAND){
                        contador_una_mano++;
                    }
                    if(visibleTreasures.get(j).getType() == TreasureKind.BOTHHANDS){
                        dos_manos = true;
                    }
                }
                if(contador_una_mano > 2 || dos_manos){
                    puedo = false;
                }
            }
            else{
                if(visibleTreasures.get(i).getType() == t.getType())
                    puedo = false;
                else{
                    if(t.getType() == TreasureKind.BOTHHANDS){
                        for(int j=0; j<tam_visible; j++){
                            if(visibleTreasures.get(j).getType() == TreasureKind.ONEHAND){
                                puedo = false;
                            }
                        }
                    }
                }
            }
            
        }
       
        return puedo;
    }
    
    private int howManyVisibleTreasures(TreasureKind tKind){
        int number = 0;
        
        for(int i=0; i<visibleTreasures.size(); i++){
            if(visibleTreasures.get(i).getType() == tKind)
                number++;
        }
        
        return number;
    }
    
    private void dieIfNoTreasures(){
        if(visibleTreasures.size()==0 && hiddenTreasures.size()==0){
            dead = true;
        }
    }
    
    public boolean isDead(){
        return dead;
    }
    
    public ArrayList<Treasure> getHiddenTreasures(){
        return hiddenTreasures;
    }
    
    public ArrayList<Treasure> getVisibleTreasures(){
        return visibleTreasures;
    }
    
    public CombatResult combat(Monster m){
        CombatResult cr;
       int myLevel = this.getCombatLevel();
       int monsterLevel = this.getOponentLevel(m);
       
       if(!canISteal){
           Dice dice = Dice.getInstance();
           int number = dice.nextNumber();
           
           if(number < 3){
            int enemyLevel = enemy.getCombatLevel();
            
            monsterLevel += enemyLevel;
           }
       }
       
       if(myLevel > monsterLevel){
           applyPrize(m);
           
           if(this.level >= Player.MAXLEVEL)
               cr = CombatResult.WINGAME;
           else
               cr = CombatResult.WIN;
       }
       else{
           applyBadConsequence(m);
           boolean should = shouldConvert();
           if(should){
               cr = CombatResult.LOSEANDCONVERT;
           }
           else{
               cr = CombatResult.LOSE;
           }
       }

       return cr;
    }
    
    public void makeTreasureVisible(Treasure t){
        boolean canI = canMakeTreasureVisible(t);
        
        if(canI){
            visibleTreasures.add(t);
            hiddenTreasures.remove(t);
        }
        
    }
    
    public void discardVisibleTresaure(Treasure t){
        visibleTreasures.remove(t);
        
        if((pendingBadConsequence != null) && (!pendingBadConsequence.isEmpty())){
            pendingBadConsequence.substractVisibleTreasure(t);
        }
        
        this.dieIfNoTreasures();
    }
    
    public void discardHiddenTreasure(Treasure t){
        hiddenTreasures.remove(t);
        
        if((pendingBadConsequence != null) && (!pendingBadConsequence.isEmpty())){
            pendingBadConsequence.substractHiddenTreasure(t);
        }
        
        this.dieIfNoTreasures();
    }
    
    public boolean validState(){
        boolean valid;
        
        if(pendingBadConsequence == null){
            if(hiddenTreasures.size() <= 4)
                valid = true;
            else
                valid = false;
        }
        else{
            if(pendingBadConsequence.isEmpty() && hiddenTreasures.size() <= 4)
                valid = true;
            else
                valid = false;
        }
        
        return valid;
    }
    
    public void initTreasures(){
        CardDealer dealer = CardDealer.getInstance();
        Dice dice = Dice.getInstance();
        
        this.bringToLife();
        
        Treasure treasure = dealer.nextTreasure();
        hiddenTreasures.add(treasure);
        
        int number = dice.nextNumber();
        
        if(number > 1){
            treasure = dealer.nextTreasure();
            hiddenTreasures.add(treasure);
        }
        
        if(number == 6){
            treasure = dealer.nextTreasure();
            hiddenTreasures.add(treasure);
        }
    }
    
    public int getLevels(){
        return level;
    }
    
    public Treasure stealTreasure(){
        boolean canI = canISteal();
        Treasure treasure = null;
        if(canI){
            boolean canYou = enemy.canYouGiveMeATreasure();
            
            if(canYou){
                treasure = enemy.giveMeATreasure();
                hiddenTreasures.add(treasure);
                haveStolen();
            }
        }
        
        return treasure;
    }
    
    public void setEnemy(Player e){
        enemy= e;
    }
    
    private Treasure giveMeATreasure(){
        int number;
        
        number = (int) (Math.random()*hiddenTreasures.size());
        
        return hiddenTreasures.get(number);
    }
    
    public boolean canISteal(){
        return canISteal;
    }
    
    private boolean canYouGiveMeATreasure(){
        boolean have = false;
        
        if(visibleTreasures.size() > 0 || hiddenTreasures.size() > 0){
            have = true;
        }
        else{
            have = false;
        }
        
        return have;
    }
    
    private void haveStolen(){
        canISteal = false;
    }
    
    public void discardAllTreasures(){
        ArrayList<Treasure> visible = new ArrayList(visibleTreasures);
        ArrayList<Treasure> hidden = new ArrayList(hiddenTreasures);
        
        for(int i=0; i<visible.size(); i++){
            Treasure treasure = visible.get(i);
            discardVisibleTresaure(treasure);
        }
        
        for(int i=0; i<hidden.size(); i++){
            Treasure treasure = hidden.get(i);
            discardHiddenTreasure(treasure);
        }
    }
    
    public String toString(){
        return name + "  Level = " + Integer.toString(level) + "\n";
    }
}
