/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package napakalaki;

import java.util.ArrayList;

/**
 *
 * @author sergio
 */
public abstract class BadConsequence {
    static final int MAXTREASURES = 10;
    
    private String text ;
    private int levels ;
    
    public BadConsequence(String n, int l){
        text = n;
        levels = l;
    }
    
    public abstract boolean isEmpty();
    
    public String getName(){
        return text;
    }
    
    public int getLevel(){
        return levels;
    }
    
    public abstract int getnVisibleTreasures();
    
    public abstract int getnHiddenTreasures();
    
    public abstract ArrayList getVisibleTreasures();
    
    public abstract ArrayList getHiddenTreasures();
    
    public abstract void substractVisibleTreasure(Treasure t);
   
    public abstract void substractHiddenTreasure(Treasure t);
    
    public abstract BadConsequence adjustToFitTreasureLists(ArrayList<Treasure> v, ArrayList<Treasure> h);
    
    public String toString(){
        return "Text = " + text + "\nLevels = " + Integer.toString(levels) ;
    }
}