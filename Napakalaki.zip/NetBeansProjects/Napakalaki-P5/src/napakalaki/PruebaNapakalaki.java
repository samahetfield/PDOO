/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package napakalaki;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author sergio
 */
public class PruebaNapakalaki {

    /**
     * @param args the command line arguments
     */
    
//    static ArrayList<Monster> monstruos = new ArrayList();
//    
//    static ArrayList combatLevel10(ArrayList<Monster> m){
//        ArrayList<Monster> mons = new ArrayList();
//        for(int i=0; i<m.size(); i++){
//            if(m.get(i).getCombatLevel() > 10){
//                mons.add(m.get(i));
//            }
//        }
//        
//        return mons;
//    }
//    
//    static ArrayList soloPerdidaNiveles(ArrayList<Monster> m){
//        ArrayList<Monster> mons = new ArrayList();
//        
//        for(int i=0; i<m.size(); i++){
//            if(m.get(i).getBadConsequence().getLevel() > 0 && (m.get(i).getBadConsequence().getnVisibleTreasures() == 0) && m.get(i).getBadConsequence().getnHiddenTreasures() == 0 && m.get(i).getBadConsequence().getSpecificHidden().size() == 0 && m.get(i).getBadConsequence().getSpecificVisible().size() == 0){
//                mons.add(m.get(i));
//            }
//        }
//        
//        return mons;
//    }
//    
//    static ArrayList gananciaNivelMayorA1(ArrayList<Monster> m){
//        ArrayList<Monster> mons = new ArrayList();
//        for(int i=0; i<m.size(); i++){
//            if(m.get(i).getPrize().getLevel() > 1){
//                mons.add(m.get(i));
//            }
//        }
//        
//        return mons;
//    }
//    
//    static ArrayList perdidaSpecific(ArrayList<Monster> m, TreasureKind t){
//        boolean encontrado = false;
//        ArrayList<Monster> mons = new ArrayList();
//        for(int i=0; i<m.size(); i++){
//            encontrado = false;
//            ArrayList<TreasureKind> sV = m.get(i).getBadConsequence().getSpecificVisible();
//            ArrayList<TreasureKind> sH = m.get(i).getBadConsequence().getSpecificHidden();
//           
//            for(int j=0; j<sV.size() && !encontrado; j++){
//                if(sV.get(j) == t){
//                    mons.add(m.get(i));
//                    encontrado = true;
//                }
//            }
//            
//            for(int j=0; j<sH.size() && !encontrado; j++){
//                if(sH.get(j) == t){
//                    mons.add(m.get(i));
//                    encontrado = true;
//                }
//            }
//        }   
//        
//        return mons;
//    }
    
    public static void main(String[] args) {
        // TODO code application logic here
      /*  
        Prize p1 = new Prize(2,3);
        BadConsequence bc1 = new BadConsequence("Hola", 3, 1, 1);
        ArrayList<TreasureKind> v = new ArrayList();
        v.add(TreasureKind.SHOES);
        
        ArrayList<TreasureKind> h = new ArrayList();
        h.add(TreasureKind.ARMOR);
        h.add(TreasureKind.ONEHAND);
        Monster m1 = new Monster("Sergio", 13, bc1, p1);
        BadConsequence bc2 = new BadConsequence("Mala suerte", 17,v,h );
        
        Monster m2 = new Monster("Pablo", 22, bc2, p1);
        
        
        System.out.println(m1.toString());
        System.out.println("\n\n");
        System.out.print(m2.toString());
      
       
        final int MAX_VALUE = 5;
        //Monstruo 1
        BadConsequence badConsequence = new BadConsequence("Pierdes tu armadura visible y otra oculta", 0, new ArrayList(Arrays.asList(TreasureKind.ARMOR)),new ArrayList(Arrays.asList(TreasureKind.ARMOR)));
        Prize prize = new Prize(2,1);
        monstruos.add(new Monster("3 Byakhees de Bonanza", 8, badConsequence, prize));
        
        //Monstruo 2
        badConsequence = new BadConsequence("Embobados con el lindo primigenio te descartas de tu casco visible", 0, new ArrayList(Arrays.asList(TreasureKind.HELMET)), new ArrayList());
        prize = new Prize(1,1);
        monstruos.add(new Monster("Tenochtitlan", 2, badConsequence, prize));
        
        //Monstruo 3
        badConsequence = new BadConsequence("El primordial bostezo contagioso. Pierdes el calzado visible", 0, new ArrayList(Arrays.asList(TreasureKind.SHOES)),new ArrayList() );
        prize = new Prize(1,1);
        monstruos.add(new Monster("El sopor de Dunwich", 2, badConsequence, prize));
        
        //Monstruo 4
        badConsequence = new BadConsequence("Te atrapan para llevarte de fiesta y te dejan caer en mitad del vuelo. Descarta 1 mano visible y 1 mano oculta", 0, new ArrayList(Arrays.asList(TreasureKind.ONEHAND)), new ArrayList(Arrays.asList(TreasureKind.ONEHAND)));
        prize = new Prize(4,1);
        monstruos.add(new Monster("Demonios de Magaluf", 2, badConsequence, prize));
        
        //Monstruo 5
        badConsequence = new BadConsequence("Pierdes todos tus tesoros visibles", 0, 0, MAX_VALUE);
        prize = new Prize(3,1);
        monstruos.add(new Monster("El gorrón en el umbral", 13, badConsequence, prize));
        
        //Monstruo 6
        badConsequence = new BadConsequence("Pierdes la armadura visible", 0, new ArrayList(Arrays.asList(TreasureKind.ARMOR)), new ArrayList());
        prize = new Prize(2,1);
        monstruos.add(new Monster("H.P Munchcraft", 6, badConsequence, prize));
        
        //Monstruo 7
        badConsequence = new BadConsequence("Sientes bichos bajo la ropa. Descarta tu armadura visible", 0, new ArrayList(Arrays.asList(TreasureKind.ARMOR)), new ArrayList());
        prize = new Prize(1,1);
        monstruos.add(new Monster("Necrófago", 13, badConsequence, prize));
        
        //Monstruo 8
        badConsequence = new BadConsequence("Pierdes 5 niveles y 3 tesoros visibles", 5, 3, 0);
        prize = new Prize(3,2);
        monstruos.add(new Monster("El rey de rosado", 11, badConsequence, prize));
        
        //Monstruo 9
        badConsequence = new BadConsequence("Toses los pulmones y pierdes 2 niveles", 2, 0, 0);
        prize = new Prize(1,1);
        monstruos.add(new Monster("Flecher", 2, badConsequence, prize));
        
        //Monstruo 10
        badConsequence = new BadConsequence("Estos monstruos resultan bastante superficiales y te aburren mortalmente. Estas muerto", true);
        prize = new Prize(2,1);
        monstruos.add(new Monster("Los hondos", 8, badConsequence, prize));
        
        //Monstruo 11
        badConsequence = new BadConsequence("Pierdes 2 niveles y 2 tesoros ocultos", 2, 0, 2);
        prize = new Prize(2,1);
        monstruos.add(new Monster("Semillas Cthulhu", 4, badConsequence, prize));
        
        //Monstruo 12
        badConsequence = new BadConsequence("Te intentas escaquear. Pierdes 1 mano visible", 0, new ArrayList(Arrays.asList(TreasureKind.ONEHAND)), new ArrayList());
        prize = new Prize(2,1);
        monstruos.add(new Monster("Dameargo", 1, badConsequence, prize));
        
        //Monstruo 13
        badConsequence = new BadConsequence("Da mucho asquito. Pierdes 3 niveles", 3, 0, 0);
        prize = new Prize(2,1);
        monstruos.add(new Monster("Pollipólipo volante", 3, badConsequence, prize));
        
        //Monstruo 14
        badConsequence = new BadConsequence("No le hace gracia que pronuncien mal su nombre. Estas muerto", true);
        prize = new Prize(3,1);
        monstruos.add(new Monster("Yskhtihyssg-Goth", 14, badConsequence, prize));
        
        //Monstruo 15
        badConsequence = new BadConsequence("La familia te atrapa. Estas muerto", true);
        prize = new Prize(3,1);
        monstruos.add(new Monster("Familia feliz", 1, badConsequence, prize));
        
        //Monstruo 16
        badConsequence = new BadConsequence("La quinta directiva te obliga a perder 2 niveles y un tesoro 2 manos visibles", 2, new ArrayList(Arrays.asList(TreasureKind.BOTHHANDS)), new ArrayList());
        prize = new Prize(2,1);
        monstruos.add(new Monster("Roboggoth", 13, badConsequence, prize));
        
        //Monstruo 17
        badConsequence = new BadConsequence("Te asusta en la noche. Pierdes un casco visible", 0, new ArrayList(Arrays.asList(TreasureKind.HELMET)), new ArrayList());
        prize = new Prize(1,1);
        monstruos.add(new Monster("El espía sordo", 5, badConsequence, prize));
        
        //Monstruo 18
        badConsequence = new BadConsequence("Menudo susto te llevas. Pierdes 2 niveles y 5 tesoros visibles", 2, 5, 0);
        prize = new Prize(2,1);
        monstruos.add(new Monster("Tongue", 19, badConsequence, prize));
        
        //Monstruo 19
        badConsequence = new BadConsequence("Te faltan manos para tanta cabeza. Pierdes 3 nivles y tus tesoros visibles de las manos", 3, new ArrayList(Arrays.asList(TreasureKind.ONEHAND, TreasureKind.ONEHAND, TreasureKind.BOTHHANDS)), new ArrayList());
        prize = new Prize(2,1);
        monstruos.add(new Monster("Bicéfalo", 21, badConsequence, prize));
        
        
        
        System.out.println("Monstruos con nivel de combate > 10");
        ArrayList<Monster> m = PruebaNapakalaki.combatLevel10(monstruos);
        for(int i=0; i<m.size(); i++){
            System.out.println(m.get(i).toString());
        }
        
        System.out.println("Mal rollo con sólo pérdida de niveles");
        m = PruebaNapakalaki.soloPerdidaNiveles(monstruos);
        for(int i=0; i<m.size(); i++){
                System.out.println(m.get(i).toString());
            
        }
        
        System.out.println("Buen rollo con ganancia de niveles > 1");
        m = PruebaNapakalaki.gananciaNivelMayorA1(monstruos);
        for(int i=0; i<m.size(); i++){
              System.out.println(m.get(i).toString());
        }
        
        System.out.println("Perdida específica de ARMOR");
        m = PruebaNapakalaki.perdidaSpecific(monstruos, TreasureKind.ARMOR);
        for(int i=0; i<m.size(); i++){
                System.out.println(m.get(i).toString());
            
        }

        System.out.println("Perdida específica de BOTHHANDS");
        m = PruebaNapakalaki.perdidaSpecific(monstruos, TreasureKind.BOTHHANDS);
        for(int i=0; i<m.size(); i++){
            System.out.println(m.get(i).toString());
            
        }
        
        System.out.println("Perdida específica de HELMET");
        m = PruebaNapakalaki.perdidaSpecific(monstruos, TreasureKind.HELMET);
        for(int i=0; i<m.size(); i++){
                System.out.println(m.get(i).toString());
            
        }
        
        System.out.println("Perdida específica de SHOES");
        m = PruebaNapakalaki.perdidaSpecific(monstruos, TreasureKind.SHOES);
        for(int i=0; i<m.size(); i++){
                System.out.println(m.get(i).toString());
            
        }
        
        System.out.println("Perdida específica de ONEHAND");
        m = PruebaNapakalaki.perdidaSpecific(monstruos, TreasureKind.ONEHAND);
        for(int i=0; i<m.size(); i++){
                System.out.println(m.get(i).toString());
            
        }
        */
    }
    
}
